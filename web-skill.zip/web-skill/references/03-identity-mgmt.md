# 4.3 Identity Management Testing (WSTG-IDNT)

## WSTG-IDNT-01: Test Role Definitions

### Objetivo
Identificar los roles definidos en la aplicación y verificar que los privilegios asociados a cada uno estén correctamente separados.

### Metodología
- Mapear todos los roles: admin, user, moderador, API/servicio, invitado, soporte
- Verificar separación de privilegios entre roles (matriz de permisos)
- Buscar funcionalidades que un rol no debería poder acceder (ver también WSTG-ATHZ-03 Privilege Escalation)
- Revisar documentación de la aplicación o entrevistar a desarrolladores (gray-box) para entender el modelo de roles previsto
- Comparar el modelo documentado contra el comportamiento real observado

```bash
# Crear cuentas con cada rol disponible y comparar accesos:
# 1. Loguear como rol bajo (user)
# 2. Intentar acceder a endpoints / funciones de roles superiores
curl -b "session=USER_TOKEN" https://target.com/api/admin/settings
curl -b "session=USER_TOKEN" https://target.com/api/admin/users
```

---

## WSTG-IDNT-02: Test User Registration Process

### Objetivo
Verificar que el proceso de registro no pueda ser abusado para suplantar identidades o escalar privilegios.

### Pruebas
- ¿Permite registrar cuentas con rol admin mediante manipulación de parámetros? (`role=admin`, `isAdmin=true`)
- ¿Valida correctamente formato de email/username?
- ¿Envía email de verificación antes de activar la cuenta?
- ¿Permite registrar el mismo email/username múltiples veces (variando case o espacios)?
- Probar con caracteres especiales en nombre de usuario: `<script>alert(1)</script>`, `' OR 1=1--`, `../../etc/passwd`
- ¿El proceso de registro permite suplantar a otro usuario ya existente (mismo nombre, distinto case)?

```bash
# Probar mass assignment durante registro
curl -X POST https://target.com/register \
  -d "username=test&password=test123&email=test@test.com&role=admin&isAdmin=true"

# Probar registro duplicado con variación de mayúsculas
curl -X POST https://target.com/register -d "username=Admin&password=x"
curl -X POST https://target.com/register -d "username=ADMIN&password=x"
```

---

## WSTG-IDNT-03: Test Account Provisioning Process

### Objetivo
Verificar quién puede aprovisionar cuentas y bajo qué controles.

### Pruebas
- ¿Solo administradores pueden crear cuentas de otros usuarios, o cualquier usuario autenticado puede hacerlo?
- ¿El proceso de invitación/provisioning valida correctamente el rol del que invita?
- ¿Es posible provisionar una cuenta con privilegios mayores a los del usuario que la crea (escalada vía provisioning)?
- Verificar flujos de "invitar miembro al equipo" en aplicaciones multi-tenant — ¿permite especificar rol arbitrario?

```bash
# Probar creación de cuenta con rol elevado desde un usuario normal
curl -X POST https://target.com/api/team/invite \
  -H "Cookie: session=USER_TOKEN" \
  -d '{"email":"attacker@evil.com","role":"owner"}'
```

---

## WSTG-IDNT-04: Testing for Account Enumeration and Guessable User Account

### Detectar Enumeración

```bash
# Mensajes de error diferenciados:
"Username does not exist"   → enumerable
"Invalid credentials"        → no enumerable (correcto, mensaje genérico)

# Diferencias en timing:
# Si usuario inexistente responde más rápido que uno existente → enumerable
time curl -X POST https://target.com/login -d "user=admin&pass=x"
time curl -X POST https://target.com/login -d "user=noexiste123&pass=x"

# Diferencias en status code o longitud de respuesta:
# 404 para usuario inexistente vs 200 con error para existente
curl -s -o /dev/null -w "%{http_code} %{size_download}\n" \
  -X POST https://target.com/login -d "user=admin&pass=x"
```

### Técnicas de Enumeración
- Formulario de login con mensajes diferenciados ("usuario no existe" vs "contraseña incorrecta")
- Formulario "forgot password" (¿confirma explícitamente si el email existe?)
- Registro de cuenta (¿dice "este email ya está registrado"?)
- API endpoints con IDs numéricos secuenciales (`/api/users/1`, `/api/users/2`...)
- Respuestas HTTP diferentes en función de cuenta existente/no existente (código, tamaño, tiempo)

### Cuentas de Usuario Adivinables
```bash
# Probar nombres de usuario comunes/predecibles
ffuf -u https://target.com/api/users/FUZZ -w usernames-common.txt -mc 200

# Patrones predecibles: firstname.lastname, employee IDs secuenciales
for i in $(seq 1000 1100); do
  curl -s "https://target.com/api/users/$i" -o /dev/null -w "$i: %{http_code}\n"
done
```

---

## WSTG-IDNT-05: Testing for Weak or Unenforced Username Policy

### Objetivo
Evaluar si la política de nombres de usuario es predecible o débil, facilitando ataques de enumeración o suplantación.

### Pruebas
- ¿Los nombres de usuario son secuenciales o predecibles (ej. `user1`, `user2`, IDs incrementales expuestos)?
- ¿Se basan en información públicamente disponible (email corporativo, formato `nombre.apellido`)?
- ¿El sistema impone alguna política de complejidad/longitud en el username, o acepta cualquier valor?
- ¿Permite caracteres especiales o Unicode que puedan causar problemas de normalización (homoglyphs para suplantación)?
- ¿Distingue entre mayúsculas/minúsculas de forma inconsistente, permitiendo username duplicados de facto (`Admin` vs `admin`)?

```bash
# Probar homoglyphs / Unicode lookalikes para suplantar un username existente
# 'аdmin' (con 'а' cirílica) vs 'admin' (con 'a' latina)
curl -X POST https://target.com/register -d "username=аdmin&password=x"
```

### Remediación General (IDNT)
- Mensajes de error genéricos e idénticos en login/registro/recuperación de contraseña
- Rate limiting y CAPTCHA en endpoints de registro/login/forgot-password
- Validación de roles en el servidor, nunca confiar en parámetros del cliente
- IDs de usuario no secuenciales (UUID) en URLs y APIs expuestas públicamente
