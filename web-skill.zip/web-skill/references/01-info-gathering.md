# 4.1 Information Gathering (WSTG-INFO)

## WSTG-INFO-01: Search Engine Discovery / Google Dorks

### Objetivos
- Identificar información sensible indexada por buscadores
- Descubrir subdominios, archivos de configuración, credenciales expuestas

### Técnicas y Operadores
```
site:target.com                          # todo el dominio
site:target.com filetype:pdf             # PDFs expuestos
site:target.com filetype:xlsx OR xls    # hojas de cálculo
site:target.com filetype:xml OR conf OR config
site:target.com inurl:admin
site:target.com inurl:login
site:target.com intitle:"index of"      # directory listing
site:target.com "error" OR "warning" OR "exception"
site:target.com "SQL syntax"            # error SQL expuesto
cache:target.com                        # versión cacheada
```

### Recursos
- Google Hacking Database (GHDB) en exploit-db.com
- Categorías útiles: Footholds, Files with usernames, Sensitive Directories, Error Messages, Files with passwords
- Bing: `ip:x.x.x.x` para reverse IP
- Shodan: `hostname:target.com`, `ssl:target.com`
- Wayback Machine + `waybackurls target.com | grep -E "\.php|\.aspx|api"`

---

## WSTG-INFO-02: Web Server Fingerprinting

### Banner Grabbing
```bash
curl -sI https://target.com
nc target.com 80
HEAD / HTTP/1.0

# Respuesta malformada para fingerprint
curl -s "https://target.com/ HTTP/invalid"
```

### Indicadores en Headers
- `Server: Apache/2.4.41` → versión exacta
- `X-Powered-By: PHP/7.4.3`
- `X-Generator: Drupal 8`
- `X-AspNet-Version: 4.0.30319`
- Orden de headers: Apache (Date, Server, Last-Modified, ETag, Accept-Ranges, Content-Length, Connection, Content-Type)

### Herramientas
```bash
nikto -h https://target.com
nmap -sV --script=http-headers,http-server-header target.com
whatweb https://target.com
```

---

## WSTG-INFO-03: Webserver Metafiles

### Archivos a Revisar
```bash
curl https://target.com/robots.txt
curl https://target.com/sitemap.xml
curl https://target.com/security.txt
curl https://target.com/.well-known/security.txt
curl https://target.com/humans.txt
curl https://target.com/crossdomain.xml
curl https://target.com/clientaccesspolicy.xml
```

### robots.txt como Mapa
- Entradas `Disallow:` revelan rutas ocultas, áreas admin, archivos sensibles
- No confiar en que `Disallow` protege: solo sugiere al crawler

---

## WSTG-INFO-04: Enumerate Applications on Webserver

### Métodos de Descubrimiento
```bash
# DNS zone transfer (rara vez funciona)
dig axfr @ns1.target.com target.com

# Subdomain enumeration
amass enum -d target.com
sublist3r -d target.com
dnsrecon -d target.com -t brt -D /usr/share/wordlists/dnsmap.txt
ffuf -u https://FUZZ.target.com -w subdomains.txt

# Reverse IP lookup
# dig -x <IP>
host <IP>

# Port scanning para apps en puertos no estándar
nmap -sV -sC -p- --open target.com
nmap -p 8000-9000 target.com   # puertos alternativos HTTP

# Virtual host fuzzing
ffuf -u https://target.com -H "Host: FUZZ.target.com" -w subdomains.txt
```

---

## WSTG-INFO-05: Review Webpage Content for Information Leakage

### Comentarios HTML
```bash
# Buscar en source code
curl -s https://target.com | grep -i "<!--"
# Buscar credenciales en comentarios
grep -i "password\|passwd\|pwd\|secret\|key\|token" *.html
```

### JavaScript Analysis
```bash
# Descargar todos los JS
wget -r -A "*.js" https://target.com
# Buscar API keys, endpoints, credenciales
grep -rE "(api[_-]?key|apikey|secret|token|password|endpoint|url)" *.js
grep -rE "https?://[a-zA-Z0-9._/-]+" *.js | grep -v "//cdn\|//ajax"
# Buscar IPs internas
grep -rE "\b10\.\d+\.\d+\.\d+|\b192\.168\.\d+\.\d+" *.js
```

### Source Maps
```bash
# Verificar si existen source maps
curl -I https://target.com/static/js/main.chunk.js.map
# Si existe, revelan código fuente completo
```

### Herramientas Útiles
- `LinkFinder` (endpoints en JS)
- `JSScanner` (secretos en JS)
- `SecretFinder` (API keys, tokens)
- Browser DevTools → Sources → buscar en todos los archivos

---

## WSTG-INFO-06: Identify Application Entry Points

### Metodología
1. Usar proxy (Burp/ZAP) para interceptar TODA la comunicación
2. Mapear en spreadsheet:
   - URL, método HTTP (GET/POST/PUT/DELETE)
   - Parámetros (query string, body, headers, cookies)
   - Autenticado/no autenticado
   - ¿Usa TLS? ¿WebSockets?

### Puntos de Entrada a Identificar
- Formularios (campos visibles y `<input type="hidden">`)
- Parámetros query string
- HTTP headers custom (X-Forwarded-For, X-Real-IP, X-Custom-Header)
- Cookies
- JSON/XML bodies en APIs
- Archivos multipart/form-data (uploads)
- WebSocket messages
- GraphQL queries/mutations

```bash
# OWASP Attack Surface Detector
java -jar attack-surface-detector-cli.jar /ruta/al/codigo

# ZAP Spider + AJAX Spider para descubrir endpoints
```

---

## WSTG-INFO-07: Map Execution Paths

### Técnicas
- Spider automático: ZAP Spider, Burp Spider/Crawler
- AJAX Spider para SPAs
- Análisis de archivos OpenAPI/Swagger
- Revisar comentarios con links ocultos
- Analizar `_next/static/`, `__pycache__/`, archivos compilados

```bash
# Gobuster para descubrir rutas
gobuster dir -u https://target.com -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt -x php,aspx,html,js,txt
ffuf -u https://target.com/FUZZ -w wordlist.txt -mc 200,301,302,403
```

---

## WSTG-INFO-08/09: Fingerprint Web Application Framework

### Indicadores por Tecnología

**Cookies reveladoras:**
| Framework | Cookie |
|-----------|--------|
| Laravel | `laravel_session` |
| CakePHP | `cakephp` |
| Django | `csrftoken`, `sessionid` |
| WordPress | `wp-settings` |
| PHP (genérico) | `PHPSESSID` |
| Java EE | `JSESSIONID` |
| ASP.NET | `.ASPXAUTH`, `__RequestVerificationToken` |

**Headers:**
- `X-Powered-By: ASP.NET`
- `X-Generator: WordPress`
- `__VIEWSTATE` en forms → ASP.NET WebForms

**Rutas específicas:**
- WordPress: `/wp-admin/`, `/wp-content/`, `/wp-includes/`
- Drupal: `/sites/default/`, `/?q=user`
- Joomla: `/administrator/`
- Django: `/admin/` con login específico

**Archivos de fingerprint:**
```bash
curl https://target.com/wp-login.php         # WordPress
curl https://target.com/administrator/       # Joomla
curl https://target.com/Umbraco/             # Umbraco CMS
curl https://target.com/CHANGELOG.txt        # versión Drupal
```

### Herramientas
```bash
whatweb -a 3 https://target.com  # nivel agresivo
wappalyzer (extensión browser)
webtech -u https://target.com
```

---

## WSTG-INFO-10: Map Application Architecture

### Detectar Componentes de Infraestructura

**Load Balancer:**
- Cookie `BIGipServer*` → F5 BIG-IP
- Header `X-Served-By`, `X-Backend-Server`
- Diferencias en `Date` header entre requests → múltiples servidores

**Reverse Proxy / CDN:**
- Headers: `CF-RAY` (Cloudflare), `X-Cache`, `Via`
- IP del servidor real: Shodan buscar certificado SSL, SecurityTrails, old DNS records

**WAF Detection:**
```bash
wafw00f https://target.com
# Provoca respuesta del WAF con payload obvio:
curl "https://target.com/?id=1'+OR+'1'='1"
```

**Backend Database (inferencia):**
- Mensajes de error SQL (MySQL, PostgreSQL, MSSQL, Oracle)
- Tipos de errores: `[Microsoft][ODBC SQL Server Driver]`, `ORA-`, `MySQLSyntaxError`
- Extensiones de archivo: `.php` → MySQL probable, `.aspx` → MSSQL probable
