# 4.8 Testing for Error Handling (WSTG-ERRH)

## WSTG-ERRH-01: Testing for Improper Error Handling

### Resumen
Todas las aplicaciones (apps web, servidores, bases de datos) generan errores. Cuando estos no se manejan adecuadamente, pueden revelar información interna valiosa para un atacante: APIs internas, versiones de software, rutas del sistema de archivos, nombres de servicios, o incluso permitir DoS y bypass de controles.

### Provocar Errores

```bash
# 1. Tipos de datos incorrectos
?id=abc      # en vez de número
?date=not-a-date
?amount=AAAA

# 2. Valores extremos
?id=-1
?id=0
?id=999999999999999

# 3. Formato inválido
# JSON malformado: {"key": }
# XML malformado: <root><unclosed>
# Fecha inválida: 99/99/9999

# 4. Caracteres especiales
?name=<>'";&|`$

# 5. Rutas inexistentes
GET /api/v1/nonexistent-endpoint
GET /api/v2/users  # si solo existe v1

# 6. HTTP inválido / malformado
curl "https://target.com/ HTTP/0.9"
curl -X FAKEMETHOD https://target.com/
# Path extremadamente largo:
curl "https://target.com/$(python3 -c 'print("A"*10000)')"
```

### Metodología por Capa

**Servidores Web** (NGINX, Apache, IIS):
- Buscar archivos/carpetas inexistentes (404s) y observar la página de error por defecto
- Solicitar carpetas existentes y observar comportamiento (403, blank page, listing)
- Romper el RFC HTTP (headers malformados, versión HTTP inválida, paths gigantes)
- Incluso si la app maneja errores, el servidor web subyacente puede mostrarse a sí mismo si la request rompe el protocolo antes de llegar a la app

**Aplicaciones**:
1. Identificar todos los puntos de entrada de datos
2. Analizar el tipo de input esperado (strings, enteros, JSON, XML, etc.)
3. Fuzzear cada punto de entrada con datos que probablemente rompan el parser correspondiente (corchete de cierre extra en JSON, texto larguísimo donde se esperan pocos caracteres, inyección CRLF, caracteres no válidos para nombres de archivo)
4. Identificar qué servicio backend responde con el error (DB, microservicio, cola) para refinar el fuzzing

### Información a Buscar en los Errores
- Stack traces con nombres de clases/paquetes/funciones internas
- Rutas absolutas del sistema de archivos (`/var/www/app/models/User.php line 45`)
- Versiones exactas de frameworks (`Spring Framework 5.2.0`, `Django 3.1.2`)
- Nombres de bases de datos, esquemas y tablas
- Credenciales o tokens filtrados accidentalmente en mensajes de excepción
- Direcciones IP internas o nombres de host de microservicios

### Notas Importantes
- Los errores no siempre se devuelven con código HTTP 4xx/5xx: a veces se ocultan en una respuesta 200 OK ("éxito" con un cuerpo de error), o en un redirect 302
- En arquitecturas de microservicios, los mensajes de error inconsistentes entre servicios permiten mapear qué servicio maneja qué funcionalidad, facilitando ataques dirigidos

### Remediación
- Manejo de excepciones global y uniforme; nunca exponer stack traces al usuario final en producción
- Páginas de error genéricas y personalizadas para 4xx/5xx
- Logging detallado del lado del servidor (no expuesto al cliente) para debugging
- Revisar: OWASP Proactive Controls C10 (Handle All Errors and Exceptions), OWASP Error Handling Cheat Sheet

---

## WSTG-ERRH-02: Testing for Stack Traces

> Este contenido fue fusionado en WSTG-ERRH-01 (Testing for Improper Error Handling) en la versión 4.2 del WSTG. Ver técnicas arriba — el foco específico en stack traces es:

### Pruebas Específicas para Stack Traces
```bash
# Forzar excepciones no controladas enviando tipos de datos inesperados
# a parámetros que se usan en operaciones aritméticas, parsing, o casts internos
?page=999999999999999999999999999999  # overflow
?id=' (comilla suelta en contexto que espera entero)
?json_field={invalid json

# Revisar respuestas en busca de:
# - "at com.example.app.Controller.method(Controller.java:123)" (Java)
# - "in /var/www/html/app/controller.php on line 45" (PHP)
# - "File "app.py", line 123, in <module>" (Python/Django/Flask)
# - "System.NullReferenceException ... at MyApp.Controllers" (.NET)
```

### Referencias
- WSTG Appendix C - Fuzz Vectors
- OWASP Proactive Controls C10: Handle All Errors and Exceptions
- ASVS v4.1 V7.4: Error Handling
- CWE-209: Generation of Error Message Containing Sensitive Information
- CWE-728: Improper Error Handling
- OWASP Cheat Sheet Series: Error Handling Cheat Sheet
