# 4.9 Testing for Weak Cryptography (WSTG-CRYP)

## WSTG-CRYP-01: Testing for Weak Transport Layer Security

### Análisis Completo de TLS
```bash
testssl.sh --full https://target.com
sslyze --regular target.com:443
sslscan target.com:443

# Manual con openssl:
openssl s_client -connect target.com:443 -tls1  # probar TLS 1.0
openssl s_client -connect target.com:443 -ssl3   # probar SSL 3.0
openssl s_client -connect target.com:443 -cipher NULL  # null ciphers

# Verificar certificado:
echo | openssl s_client -connect target.com:443 2>/dev/null | openssl x509 -noout -text
```

### Checklist de Configuración del Servidor
- ✓ Versión ≥ TLS 1.2 (TLS 1.3 ideal)
- ✗ SSLv2, SSLv3, TLS 1.0, TLS 1.1 (deprecated, deben estar deshabilitados)
- ✗ Cipher suites débiles: RC4, DES, 3DES, EXPORT, NULL, ANON
- ✓ Forward secrecy: ECDHE, DHE en key exchange
- ✓ Certificado: SHA-256+, RSA ≥2048 bits (o ECC con curva segura), válido y de CA confiable
- ✓ HSTS header presente (ver WSTG-CONF-07)
- ✓ Sin mixed content (recursos HTTP en página HTTPS)

### Debilidades Criptográficas Conocidas
- **SSLv2 (DROWN)**
- **SSLv3 (POODLE)**
- **TLSv1.0 (BEAST)**
- **EXPORT cipher suites (FREAK)**
- **NULL ciphers** (solo autenticación, sin cifrado)
- **Anonymous ciphers** (sin autenticación del servidor)
- **RC4 ciphers (NOMORE)**
- **CBC mode ciphers (BEAST, Lucky 13)**
- **TLS compression (CRIME)**
- **Weak DHE keys (LOGJAM)**

### Vulnerabilidades de Implementación Históricas
- Debian OpenSSL Predictable RNG (CVE-2008-0166)
- OpenSSL Insecure Renegotiation (CVE-2009-3555)
- OpenSSL Heartbleed (CVE-2014-0160) → `auxiliary/scanner/ssl/openssl_heartbleed` en Metasploit
- F5 TLS POODLE (CVE-2014-8730)
- Microsoft Schannel DoS (MS14-066 / CVE-2014-6321)

### Certificados Digitales
- **Fortaleza criptográfica**: clave ≥2048 bits, firma ≥SHA-256 (evitar MD5/SHA-1)
- **Validez**: dentro del período de validez (máx. 398 días desde sept. 2020), firmado por CA confiable, SAN coincide con el hostname (el navegador moderno ignora el CN)
- **Wildcard certs** (`*.example.org`): convenientes pero implican riesgos — revisar OWASP Transport Layer Security Cheat Sheet
- Los certificados pueden filtrar nombres de dominios internos en los campos Issuer/SAN, útiles para reconocimiento

### Mixed Active Content
Recursos activos (scripts, CSS) cargados sobre HTTP e incluidos en una página HTTPS permiten a un atacante modificar dichos archivos en tránsito y ejecutar código arbitrario. El contenido pasivo (imágenes) cargado de forma insegura es menos crítico, pero puede filtrar info o permitir defacement.

### Redirect HTTP → HTTPS
Si un sitio acepta conexiones HTTP y luego redirige a HTTPS (301), un atacante en posición de interceptar esa primera conexión puede redirigir a un sitio malicioso o usar herramientas como `sslstrip`. Mitigación: estar en la lista de preload de HSTS.

### Testing Manual vs Automatizado
```bash
# Automatizado
nmap --script ssl-enum-ciphers -p 443 target.com
sslyze --regular target.com

# Manual con openssl/gnutls
openssl s_client -connect target.com:443 -cipher 'EXPORT'
gnutls-cli --priority "NORMAL:+ARCFOUR-128" target.com
```
⚠️ Verificar que la versión de OpenSSL/GnuTLS usada para testear soporte protocolos obsoletos (SSLv2, EXPORT), ya que las versiones modernas del sistema pueden no soportarlos y generar falsos negativos.

---

## WSTG-CRYP-02: Testing for Padding Oracle

### Concepto
Un padding oracle existe cuando una aplicación descifra datos cifrados proporcionados por el cliente (ej. estado de sesión almacenado en el cliente) y filtra si el padding tras el descifrado es válido o no. Esto permite a un atacante descifrar y re-cifrar datos arbitrarios sin conocer la clave.

### Identificación de Candidatos
1. El dato está cifrado (valores que parecen aleatorios/Base64)
2. Se usa un cifrado de bloque — la longitud del texto decodificado (Base64) es múltiplo de 8 o 16 bytes

```bash
# Ejemplo: Dg6W8OiWMIdVokIDH15T/A== decodifica a 16 bytes — candidato
```

### Proceso de Prueba
1. Decodificar el valor
2. Flip del último bit del bloque penúltimo (o de cada bloque, sistemáticamente)
3. Re-codificar y enviar
4. Comparar las respuestas: deben distinguirse 3 estados posibles:
   - Descifrado correcto → datos válidos
   - Descifrado "garbled" → error de lógica de aplicación
   - Fallo de padding → error específico de padding

```bash
# Herramientas automatizadas
padbuster https://target.com/decrypt.php "ENCRYPTED_VALUE" 8 -cookies "auth=ENCRYPTED_VALUE"
```

### Mensajes Reveladores
- ASP.NET: `System.Security.Cryptography.CryptographicException: Padding is invalid and cannot be removed.`
- Java: `javax.crypto.BadPaddingException`

### Remediación (Gray-box)
- Verificar integridad del texto cifrado con HMAC o modos autenticados (GCM, CCM)
- Manejar todos los estados de error de descifrado de forma uniforme (solo "ok" / "failed", sin distinción de causa)

---

## WSTG-CRYP-03: Testing for Sensitive Information Sent via Unencrypted Channels

### Información Sensible a Buscar
- Credenciales, PINs, session IDs, tokens, cookies
- Datos protegidos por regulación: números de tarjeta, SSN, información de salud, datos de pasaporte

### Ejemplos de Test

**Basic Auth sobre HTTP:**
```bash
curl -kis http://example.com/restricted/
# WWW-Authenticate: Basic realm="Restricted Area" → credenciales solo codificadas, no cifradas
```

**Formulario de autenticación sobre HTTP:**
```html
<form action="http://example.com/login">
```

**Cookie de sesión sin flag Secure, enviada en login HTTP:**
```http
Set-Cookie: JSESSIONID=...; path=/; domain=example.com; httponly
# Falta el flag Secure → la cookie puede viajar sobre HTTP
```

**Buscar información sensible en código/logs:**
```bash
grep -r -E "Pass|password|pwd|user|guest|admin|encry|key|decrypt|sharekey" ./PathToSearch/
grep -r " \{2\}[0-9]\{6\} " ./PathToSearch/   # patrones de PII numérica
```

### Herramientas
- `curl`, `grep`
- Wireshark, TCPDUMP (capturar tráfico en tránsito)
- Identity Finder (escaneo de PII)

---

## WSTG-CRYP-04: Testing for Weak Encryption

### Checklist de Seguridad Básico
- IV (Initialization Vector) en AES debe ser aleatorio e impredecible — usar `SecureRandom`, nunca `java.util.Random`
- Para cifrado asimétrico: preferir ECC con curva segura (Curve25519); si no, RSA con mínimo 2048 bits
- Firmas RSA: usar padding PSS
- Algoritmos prohibidos: MD5, RC4, DES, Blowfish, SHA1, RSA/DSA de 1024 bits, ECDSA de 160 bits, 2TDEA de 80/112 bits

### Longitudes de Clave Mínimas Recomendadas
```
Key exchange:          Diffie-Hellman ≥2048 bits
Message Integrity:     HMAC-SHA2
Message Hash:          SHA2 256 bits
Asymmetric encryption: RSA 2048 bits
Symmetric encryption:  AES 128 bits
Password Hashing:      PBKDF2, Scrypt, Bcrypt
ECDH/ECDSA:            256 bits
```

- No usar CBC mode con SSH
- No usar ECB mode con cifrado simétrico
- PBKDF2: iteraciones >10,000 (NIST recomienda mínimo 10,000); nunca usar PBKDF2WithHmacMD5

### Revisión de Código Fuente
```bash
# Buscar algoritmos débiles
grep -rE "MD4|MD5|RC4|RC2|DES\b|Blowfish|SHA-1|ECB" /path/to/source

# Java: revisar parámetros de cifrado
SecretKeyFactory(SecretKeyFactorySpi keyFacSpi, Provider provider, String algorithm)
Cipher c = Cipher.getInstance("DES/CBC/PKCS5Padding");  # DES es débil

# Padding RSA recomendado:
RSA/ECB/OAEPWithSHA-1AndMGF1Padding (2048)
RSA/ECB/OAEPWithSHA-256AndMGF1Padding (2048)

# Buscar IV estático/reusado (vulnerabilidad):
IvParameterSpec iv = new IvParameterSpec(randBytes);  # ✓ correcto si randBytes es aleatorio
# vs.
byte[] fixedIv = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};  # ✗ IV fijo, inseguro

# Buscar hash débil:
MessageDigest md5 = MessageDigest.getInstance("MD5");  # ✗
Signature sig = Signature.getInstance("SHA1withRSA");  # ✗

# Revisar parámetros de PBKDF2:
private static byte[] pbkdf2(char[] password, byte[] salt, int iterations, int bytes)
# iterations debe ser >10000, salt debe ser aleatorio
```

### Palabras Clave para Buscar Secretos Hardcodeados
```
Usuario: name, root, su, sudo, admin, superuser, login, username, uid
Claves: public key, AK, SK, secret key, private key, passwd, password, pwd,
        share key, shared key, crypto, base64
Otros: sysadmin, root, privilege, pass, key, code, master, admin, uname,
       session, token, Oauth, privatekey, shared secret
```

### Cracking de Hashes Encontrados
```bash
hashcat -a 0 -m 0 hashes.txt rockyou.txt      # MD5
hashcat -a 0 -m 100 hashes.txt rockyou.txt    # SHA1
hashcat -a 0 -m 1800 hashes.txt rockyou.txt   # SHA-512 crypt
john --format=bcrypt hashes.txt rockyou.txt   # bcrypt
```

### Remediación
- OWASP Cryptographic Storage Cheat Sheet
- Usar siempre librerías criptográficas estándar y revisadas, nunca implementaciones propias
