# 4.2 Configuration and Deployment Management Testing (WSTG-CONF)

## WSTG-CONF-01: Network Infrastructure Configuration

### Verificar Vulnerabilidades Conocidas
```bash
nmap -sV --script=vuln,http-headers,http-methods target.com
nikto -h https://target.com -Tuning 1234567890
# Buscar versiones con CVEs conocidos en NVD/Exploit-DB
```

### Interfaces Administrativas
- Comprobar puertos: 8080, 8443, 9090, 4848 (GlassFish), 7001 (WebLogic), 8161 (ActiveMQ)
- Revisar acceso desde Internet a: phpMyAdmin, Adminer, JMX, Redis, Elasticsearch, MongoDB

---

## WSTG-CONF-02: Application Platform Configuration

### Archivos y Directorios por Defecto
```bash
# Buscar páginas de ejemplo/test
gobuster dir -u https://target.com -w /usr/share/wordlists/dirb/common.txt
# Comprobar archivos típicos expuestos
curl https://target.com/info.php          # PHP info
curl https://target.com/phpinfo.php
curl https://target.com/test.php
curl https://target.com/server-status     # Apache
curl https://target.com/server-info
curl https://target.com/elmah.axd         # ASP.NET error log
curl https://target.com/trace.axd
curl https://target.com/.git/HEAD         # Git expuesto
curl https://target.com/.env              # Variables de entorno
curl https://target.com/docker-compose.yml
curl https://target.com/Dockerfile
curl https://target.com/web.config
curl https://target.com/WEB-INF/web.xml
```

### Git Expuesto
```bash
# Si /.git/HEAD devuelve contenido:
git-dumper https://target.com/.git/ ./dumped-repo
# O manualmente:
curl https://target.com/.git/config
curl https://target.com/.git/COMMIT_EDITMSG
curl https://target.com/.git/logs/HEAD
```

### Logging Review
- Verificar que logs NO contengan: passwords, session IDs, tokens, datos PII
- Confirmar logs están en partición separada del web root
- Verificar que logs no son accesibles vía web

---

## WSTG-CONF-03: File Extensions Handling

### Extensions Peligrosas a Probar
```bash
# Extensiones que revelan código fuente
curl https://target.com/index.php.bak
curl https://target.com/config.php.old
curl https://target.com/login.asp.old
curl https://target.com/web.config.bak

# Archives que pueden contener código
curl https://target.com/backup.zip
curl https://target.com/source.tar.gz
curl https://target.com/app.war

# Inclusiones sensibles
curl https://target.com/config.inc
curl https://target.com/database.inc
curl https://target.com/conn.php
```

### Windows 8.3 Filename Bypass
- `file.phtml` procesado como PHP
- `SHELL~1.PHP` expandido por OS

---

## WSTG-CONF-04: Old Backup and Unreferenced Files

### Wordlists de Backup
```bash
# ffuf con extensiones de backup
ffuf -u https://target.com/FUZZ -w wordlist.txt \
  -e ".bak,.old,.tmp,.swp,.~,.copy,.orig,.backup,.sql,.dump"

# Buscar por nombre de archivo existente
# Si existe login.php, probar:
curl https://target.com/login.php.bak
curl https://target.com/login.php.old
curl https://target.com/login.php~
curl https://target.com/login.php.swp   # vim swap file
curl https://target.com/.login.php.swp
```

### Editores que dejan archivos
- Vim: `.filename.swp`, `filename~`
- Emacs: `filename~`, `#filename#`
- Nano: `filename~`
- Windows: `Copy of filename`

### Directory Listing
```bash
# Buscar directorios con listing habilitado
curl https://target.com/uploads/
curl https://target.com/files/
curl https://target.com/images/
# Respuesta con "<title>Index of" indica listing activo
```

---

## WSTG-CONF-05: Admin Interfaces

### Rutas Comunes
```bash
# Wordlist específica de admin paths
ffuf -u https://target.com/FUZZ -w admin-paths.txt

# Rutas genéricas
/admin  /administrator  /administrador  /admin.php
/manage  /management  /manager
/panel  /cpanel  /control
/dashboard  /console
/backend  /backoffice  /back-office
/staff  /superuser  /root
/wp-admin (WordPress)  /user/login (Drupal)  /administrator (Joomla)

# Tecnología específica
/phpmyadmin  /mysqladmin  /dbadmin  /adminer.php
/jenkins  /sonarqube  /grafana  /kibana  /prometheus
/actuator  /actuator/env  /actuator/health  # Spring Boot
```

### Bypass de Autenticación Admin
- Probar credenciales por defecto (admin/admin, admin/password, root/root)
- Verificar si hay rate limiting en el formulario
- Intentar bypass con parámetros: `?admin=true`, `?debug=1`, cookies `admin=true`

---

## WSTG-CONF-06: HTTP Methods

### Enumerar Métodos Permitidos
```bash
# Con nmap
nmap -p 443 --script http-methods --script-args http-methods.url-path='/' target.com

# Con curl
curl -s -X OPTIONS https://target.com -i | grep -i allow

# Con netcat
nc target.com 80
OPTIONS / HTTP/1.1
Host: target.com
```

### Probar Métodos Peligrosos

**PUT (upload arbitrario):**
```bash
curl -X PUT https://target.com/test.html -d "<html>test</html>"
# Verificar si subió:
curl https://target.com/test.html
```

**DELETE:**
```bash
curl -X DELETE https://target.com/test.html
```

**TRACE (XST - Cross-Site Tracing):**
```bash
curl -X TRACE https://target.com -H "Cookie: session=abc123"
# Si responde con los headers incluidos → XST posible
```

### HTTP Method Override (Bypass WAF/Firewall)
```bash
# Cuando DELETE/PUT devuelve 405:
curl -X POST https://target.com/resource \
  -H "X-HTTP-Method: DELETE"
curl -X POST https://target.com/resource \
  -H "X-HTTP-Method-Override: DELETE"
curl -X POST https://target.com/resource \
  -H "X-Method-Override: DELETE"
```

### Access Control Bypass con Métodos
```bash
# Si GET /admin devuelve 302/401, probar otros métodos:
curl -X HEAD https://target.com/admin
curl -X POST https://target.com/admin
curl -X RANDOM https://target.com/admin  # método inválido
```

---

## WSTG-CONF-07: HTTP Strict Transport Security (HSTS)

```bash
curl -sI https://target.com | grep -i strict
# Debe contener:
# Strict-Transport-Security: max-age=31536000; includeSubDomains; preload

# Verificar:
# max-age >= 31536000 (1 año)
# includeSubDomains presente
# Acceso HTTP redirige a HTTPS (no bypass)
```

---

## WSTG-CONF-08: RIA Cross-Domain Policy

```bash
# Adobe Flash crossdomain
curl https://target.com/crossdomain.xml
# Silverlight
curl https://target.com/clientaccesspolicy.xml

# Flags de riesgo:
# <allow-access-from domain="*" />  → cualquier dominio puede acceder
# secure="false" → permite HTTP en vez de solo HTTPS
```

---

## WSTG-CONF-09: File Permissions

```bash
# En servidor Linux (si hay acceso SSH/shell)
namei -l /var/www/html/
find /var/www -perm -o+w -ls  # archivos world-writable
find /var/www -name "*.php" -perm /111 -ls  # PHP ejecutables
ls -la /etc/cron*  # tareas cron con permisos inseguros
```

---

## WSTG-CONF-10: Subdomain Takeover

### Proceso de Detección
```bash
# 1. Enumerar subdominios
amass enum -d target.com -o subdomains.txt
subfinder -d target.com

# 2. Para cada subdominio, verificar CNAME:
dig CNAME sub.target.com
# Si el CNAME apunta a servicio no reclamado (NXDOMAIN):

# 3. Verificar si el servicio está disponible para registro
# Servicios comunes: GitHub Pages, Heroku, Netlify, Vercel, 
# Azure, AWS S3, Shopify, Fastly, Zendesk

# 4. Herramientas automáticas
subjack -w subdomains.txt -t 100 -ssl
nuclei -l subdomains.txt -t takeovers/
```

### Servicios Vulnerables Comunes
- **GitHub Pages**: 404 "There isn't a GitHub Pages site here"
- **AWS S3**: `NoSuchBucket` o `BucketNotFound`
- **Heroku**: "No such app"
- **Fastly**: `Fastly error: unknown domain`
- **Shopify**: "Sorry, this shop is currently unavailable"

---

## WSTG-CONF-11: Cloud Storage Misconfiguration

### AWS S3
```bash
# Identificar bucket en respuestas HTTP/source code
# URLs: https://bucket.s3.amazonaws.com o https://s3.amazonaws.com/bucket

# Probar acceso público:
curl https://target-bucket.s3.amazonaws.com/
aws s3 ls s3://target-bucket --no-sign-request  # sin credenciales
aws s3 cp test.txt s3://target-bucket/test.txt --no-sign-request  # upload

# Listar objetos:
aws s3 ls s3://target-bucket --no-sign-request

# Herramientas:
# AWSBucketDump, s3scanner, bucket-finder
```

### Google Cloud Storage
```bash
curl https://storage.googleapis.com/target-bucket/
gsutil ls gs://target-bucket/  # sin credenciales
```

### Azure Blob Storage
```bash
# Formato: https://account.blob.core.windows.net/container
curl https://targetaccount.blob.core.windows.net/targetcontainer?restype=container&comp=list
```
